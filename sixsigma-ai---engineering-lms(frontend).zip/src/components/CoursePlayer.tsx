import React, { useState, useRef, useEffect } from 'react';
import { UserSession, ViewState } from '../types';
import { 
  ArrowLeft, 
  Play, 
  Pause, 
  Volume2, 
  Maximize, 
  CheckCircle, 
  BookOpen, 
  Download, 
  FileText, 
  MessageSquare,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  X,
  Send,
  HelpCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { MOCK_COURSES } from '../data/courses';

interface CoursePlayerProps {
  courseId: string;
  initialLectureIndex: number;
  setView: (view: ViewState) => void;
  session: UserSession;
}

export default function CoursePlayer({ courseId, initialLectureIndex, setView, session }: CoursePlayerProps) {
  const [activeLectureIdx, setActiveLectureIdx] = useState(initialLectureIndex);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  
  // Custom interactive AI Tutor Box in Player
  const [chatMessages, setChatMessages] = useState<Array<{ sender: 'user' | 'tutor'; text: string }>>([
    { sender: 'tutor', text: `Hi ${session.user?.name || 'Engineer'}! Ask me anything about this lecture's technical parameters, formulas, or how to implement the capstone sandbox!` }
  ]);
  const [promptValue, setPromptValue] = useState('');
  const [isLobeReplying, setIsLobeReplying] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);

  const course = MOCK_COURSES.find(c => c.id === courseId) || MOCK_COURSES[0];
  const activeLecture = course.lessons[activeLectureIdx] || course.lessons[0];

  useEffect(() => {
    // Reset video when lecture index shifts
    if (videoRef.current) {
      videoRef.current.load();
      setIsPlaying(false);
    }
  }, [activeLectureIdx]);

  const togglePlayState = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play().catch(() => {});
      }
      setIsPlaying(!isPlaying);
    }
  };

  const handleTimeUpdate = () => {
    if (videoRef.current) {
      setCurrentTime(videoRef.current.currentTime);
      setDuration(videoRef.current.duration || 0);
    }
  };

  const handleScrubberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    if (videoRef.current) {
      videoRef.current.currentTime = value;
      setCurrentTime(value);
    }
  };

  const formatVideoTime = (secs: number) => {
    if (isNaN(secs)) return '0:00';
    const mins = Math.floor(secs / 60);
    const remainingSecs = Math.floor(secs % 60);
    return `${mins}:${remainingSecs < 10 ? '0' : ''}${remainingSecs}`;
  };

  const handleSendPromptSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promptValue.trim()) return;

    const userText = promptValue;
    setChatMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setPromptValue('');
    setIsLobeReplying(true);

    setTimeout(() => {
      let reply = `Based on our Sixsigma AI database, that concept requires understanding local limits. `;
      if (userText.toLowerCase().includes('formula') || userText.toLowerCase().includes('matlab')) {
        reply = `To simulate this in MATLAB, define your control state matrix or use direct block diagram connections. Verify your sampling frequency parameters in Minitab to filter continuous noise.`;
      } else if (userText.toLowerCase().includes('six sigma') || userText.toLowerCase().includes('dmaic')) {
        reply = `To calculate standard DMAIC ratios, use baseline yield statistics. Determine your DPU (Defects per Unit) rate prior to compiling FMEA structures.`;
      } else {
        reply = `That is extremely important for your hands-on assignment. Ensure you keep your capstone sandbox files structured and formatted according to your course study materials list.`;
      }
      setChatMessages(prev => [...prev, { sender: 'tutor', text: reply }]);
      setIsLobeReplying(false);
    }, 1200);
  };

  return (
    <div className="bg-[#070A11] min-h-screen text-gray-200" id="course-player-view">
      
      {/* Top distration-free navigation bar */}
      <div className="bg-gray-950 border-b border-gray-900 px-4 sm:px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-3">
          <button 
            onClick={() => setView({ type: 'dashboard' })}
            className="p-2 border border-gray-800 hover:border-gray-700 text-gray-400 hover:text-white rounded-lg transition-colors cursor-pointer"
          >
            <ArrowLeft className="h-4 w-4" />
          </button>
          <div>
            <span className="text-[10px] uppercase font-mono font-bold text-amber-400">{course.category} SPECIALIST BATCH</span>
            <h2 className="text-sm font-sans font-extrabold text-white leading-tight truncate max-w-md sm:max-w-xl">{course.title}</h2>
          </div>
        </div>

        <button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="px-3.5 py-1.5 border border-gray-800 hover:border-gray-500 rounded-lg text-xs font-semibold cursor-pointer transition-colors"
        >
          {sidebarOpen ? 'Collapse Sidebar ➔' : '📂 Course Outline'}
        </button>
      </div>

      {/* Main split grid */}
      <div className="flex flex-col lg:flex-row min-h-[calc(100vh-76px)]">
        
        {/* Left Video viewport / Player controls details */}
        <div className="flex-grow p-4 sm:p-6 lg:p-8 space-y-6 flex flex-col justify-between max-w-5xl">
          
          <div className="space-y-4">
            
            {/* Real HTML5 sandbox player with mockup chrome controls wrapper */}
            <div className="relative bg-black rounded-2xl overflow-hidden aspect-video shadow-2xl ring-1 ring-gray-800 group">
              <video 
                ref={videoRef}
                onTimeUpdate={handleTimeUpdate}
                onClick={togglePlayState}
                className="w-full h-full object-contain"
                src={activeLecture.videoUrl}
              />

              {/* HTML5 video playback mockup overlay controls */}
              <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/90 via-black/40 to-transparent p-4 flex flex-col gap-3 group-hover:opacity-100 transition-opacity">
                
                {/* Scrubber slider bar */}
                <div className="flex items-center gap-3">
                  <span className="text-xs font-mono text-gray-400">{formatVideoTime(currentTime)}</span>
                  <input 
                    type="range"
                    min={0}
                    max={duration || 100}
                    value={currentTime}
                    onChange={handleScrubberChange}
                    className="flex-grow accent-amber-400 bg-gray-700 h-1 rounded-full cursor-pointer"
                  />
                  <span className="text-xs font-mono text-gray-400">{formatVideoTime(duration)}</span>
                </div>

                {/* Left Play state button & Volume */}
                <div className="flex justify-between items-center">
                  <div className="flex items-center gap-4">
                    <button 
                      onClick={togglePlayState}
                      className="p-2.5 bg-amber-400 hover:bg-amber-500 text-gray-950 rounded-full transition-all cursor-pointer transform hover:scale-105"
                    >
                      {isPlaying ? <Pause className="h-4 w-4 fill-gray-950" /> : <Play className="h-4 w-4 fill-gray-950" />}
                    </button>

                    <div className="flex items-center gap-1.5 text-gray-300 text-xs">
                      <Volume2 className="h-4 w-4 text-gray-400" />
                      <span className="font-mono">100%</span>
                    </div>
                  </div>

                  {/* Right Maximizer */}
                  <button 
                    onClick={() => videoRef.current?.requestFullscreen()}
                    className="p-1.5 hover:bg-gray-800 text-gray-400 hover:text-white rounded transition-colors"
                  >
                    <Maximize className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Large central play state indicator if paused */}
              {!isPlaying && (
                <div 
                  onClick={togglePlayState}
                  className="absolute inset-0 bg-transparent flex items-center justify-center cursor-pointer"
                >
                  <div className="p-5 sm:p-7 bg-amber-400/90 text-gray-950 rounded-full shadow-2xl transform transition-transform hover:scale-110">
                    <Play className="h-8 w-8 fill-gray-950 translate-x-0.5" />
                  </div>
                </div>
              )}
            </div>

            {/* Lesson detail headings */}
            <div>
              <span className="font-mono text-xs font-bold text-amber-400 uppercase tracking-widest block">
                Active Lecture: Episode {activeLectureIdx + 1} of {course.lessons.length}
              </span>
              <h3 className="text-xl sm:text-2xl font-sans font-extrabold text-white mt-1">
                {activeLecture.title}
              </h3>
              <p className="text-xs text-gray-405 mt-1.5 leading-relaxed max-w-3xl">
                This capsule introduces key architectural design configurations. Please download corresponding files from materials sidebar before executing local sandbox calculations.
              </p>
            </div>

          </div>

          {/* Quick prev/next page footer buttons */}
          <div className="flex justify-between items-center border-t border-gray-900 pt-6">
            <button
              disabled={activeLectureIdx === 0}
              onClick={() => setActiveLectureIdx(prev => prev - 1)}
              className="px-4 py-2 border border-gray-850 hover:border-gray-500 disabled:opacity-30 rounded-lg text-xs font-bold transition-all flex items-center gap-1 cursor-pointer"
            >
              <ChevronLeft className="h-4 w-4" /> Previous Lecture
            </button>

            <button
              disabled={activeLectureIdx >= course.lessons.length - 1}
              onClick={() => setActiveLectureIdx(prev => prev + 1)}
              className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 disabled:opacity-35 font-extrabold rounded-lg text-xs uppercase tracking-wide cursor-pointer flex items-center gap-1 shadow-md"
            >
              Next Lecture <ChevronRight className="h-4 w-4" />
            </button>
          </div>

        </div>

        {/* Right Collapsible sidebar containing Curriculum Outline & Downloadable Resources */}
        <AnimatePresence>
          {sidebarOpen && (
            <motion.div 
              initial={{ width: 0, opacity: 0 }}
              animate={{ width: 380, opacity: 1 }}
              exit={{ width: 0, opacity: 0 }}
              className="bg-gray-955 border-l border-gray-900 w-[380px] shrink-0 overflow-y-auto flex flex-col justify-between"
              id="course-sidebar-wrapper"
            >
              
              {/* Core Lessons list */}
              <div className="p-5 space-y-6">
                <div>
                  <h4 className="font-sans font-bold text-white text-sm uppercase tracking-wide flex items-center gap-1.5 mb-4 font-mono">
                    <BookOpen className="h-4 w-4 text-amber-400" /> Syllabus Progress
                  </h4>

                  <div className="space-y-2">
                    {course.lessons.map((lesson, idx) => (
                      <button
                        key={idx}
                        onClick={() => setActiveLectureIdx(idx)}
                        className={`w-full text-left p-3 rounded-xl border transition-all flex gap-3 text-xs ${
                          activeLectureIdx === idx
                            ? 'bg-amber-400/5 border-amber-400 text-white font-black'
                            : 'bg-gray-900/40 border-gray-850 text-gray-300 hover:bg-gray-900'
                        }`}
                      >
                        <span className="p-1 px-2 bg-gray-800 rounded text-[10px] font-mono h-fit">
                          {idx + 1}
                        </span>
                        <div>
                          <div className="font-semibold leading-snug">{lesson.title}</div>
                          <span className="text-[10px] text-gray-500 mt-1 block font-mono">🎬 Duration: {lesson.duration}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Materials & Resources download card */}
                <div className="border-t border-gray-900 pt-5">
                  <h4 className="font-sans font-bold text-white text-sm uppercase tracking-wide flex items-center gap-1.5 mb-4 font-mono">
                    <Download className="h-4 w-4 text-emerald-400" /> Lesson Support Files
                  </h4>

                  <div className="space-y-3.5">
                    {course.resources.map((file, idx) => (
                      <a 
                        key={idx}
                        href="#"
                        onClick={(e) => { e.preventDefault(); alert("File downloaded! Double check local folder directory."); }}
                        className="bg-gray-900 border border-gray-850 p-3 rounded-xl flex items-center justify-between hover:border-emerald-500/50 transition-colors group"
                      >
                        <div className="space-y-0.5 truncate max-w-[200px]">
                          <div className="font-bold text-gray-200 text-[11px] truncate group-hover:text-emerald-300 transition-colors">{file.name}</div>
                          <span className="text-[10px] text-gray-500 font-mono italic">{file.size}</span>
                        </div>
                        <FileText className="h-4 w-4 text-gray-500 group-hover:text-emerald-400 transition-colors" />
                      </a>
                    ))}
                  </div>
                </div>
              </div>

              {/* Integrated AI chat module inside sidebar */}
              <div className="border-t border-gray-900 bg-gray-950 p-4 space-y-4">
                <div className="flex justify-between items-center text-xs font-bold uppercase font-mono tracking-wide text-amber-400">
                  <span className="flex items-center gap-1.5"><Sparkles className="h-3.5 w-3.5" /> 24x7 AI Homework Tutor</span>
                </div>

                <div className="h-44 overflow-y-auto bg-gray-900/60 border border-gray-850 p-2.5 rounded-xl space-y-2.5 text-[11px] font-mono">
                  {chatMessages.map((msg, idx) => (
                    <div 
                      key={idx}
                      className={`p-2 rounded-lg leading-normal ${
                        msg.sender === 'user' 
                          ? 'bg-amber-400/10 text-amber-300 border border-amber-500/20 text-right ml-4' 
                          : 'bg-gray-800 text-gray-350 mr-4'
                      }`}
                    >
                      {msg.text}
                    </div>
                  ))}
                  {isLobeReplying && (
                    <div className="text-gray-500 italic animate-pulse">Assistant typing equations parameters...</div>
                  )}
                </div>

                <form onSubmit={handleSendPromptSubmit} className="flex gap-2">
                  <input 
                    type="text"
                    value={promptValue}
                    onChange={(e) => setPromptValue(e.target.value)}
                    placeholder="Type formula query..."
                    className="flex-grow bg-gray-900 border border-gray-850 focus:border-amber-400 rounded-lg px-2.5 py-2 text-[11px] font-mono text-white focus:outline-none"
                  />
                  <button 
                    type="submit"
                    className="p-2 bg-amber-400 hover:bg-amber-500 text-gray-950 rounded-lg shrink-0 transition-colors cursor-pointer"
                  >
                    <Send className="h-3.5 w-3.5 fill-gray-950" />
                  </button>
                </form>
              </div>

            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
