import React, { useState } from 'react';
import { UserSession, ViewState, UserRole } from '../types';
import { 
  Mail, 
  Lock, 
  User, 
  Award, 
  ChevronRight, 
  ArrowLeft, 
  CheckCircle, 
  AlertCircle,
  GraduationCap
} from 'lucide-react';
import { motion } from 'motion/react';

interface AuthInterfaceProps {
  session: UserSession;
  setSession: (session: UserSession) => void;
  setView: (view: ViewState) => void;
  isSignUpInitial?: boolean;
}

export default function AuthInterface({ session, setSession, setView, isSignUpInitial = false }: AuthInterfaceProps) {
  const [isSignUp, setIsSignUp] = useState(isSignUpInitial);
  const [isReset, setIsReset] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [role, setRole] = useState<UserRole>('fresher');
  const [branch, setBranch] = useState('electrical');
  
  // validation states
  const [errorText, setErrorText] = useState('');
  const [successText, setSuccessText] = useState('');

  const handleValidationAndSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText('');
    setSuccessText('');

    if (!email || !email.includes('@')) {
      setErrorText('Please specify a valid professional email address.');
      return;
    }

    if (!isReset) {
      if (!password || password.length < 6) {
        setErrorText('Password must be at least 6 characters.');
        return;
      }
    }

    if (isReset) {
      setSuccessText('Password reset instructions have been dispatched to your email.');
      setTimeout(() => {
        setIsReset(false);
        setSuccessText('');
      }, 4000);
      return;
    }

    // Process Logging in or Registering
    const userRole = role;
    const userBranch = branch;
    const resolvedName = isSignUp ? fullName || 'Professional Engineer' : 'Ramesh Kumar';

    setSession({
      isLoggedIn: true,
      user: {
        name: resolvedName,
        email,
        role: userRole,
        branch: userBranch,
        isPremium: userRole !== 'fresher' // Let Experienced and Managers start as Premium
      }
    });

    setSuccessText(isSignUp ? 'Registration successful! Launching workspace...' : 'Welcome back! Activating secure profile session...');
    
    setTimeout(() => {
      setView({ type: 'dashboard' });
    }, 1500);
  };

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 flex items-center justify-center py-16 px-4" id="auth-interface-root">
      <div className="w-full max-w-md bg-gray-900 border border-gray-850 p-8 sm:p-10 rounded-3xl shadow-2xl relative">
        <div className="absolute right-0 top-0 h-24 w-24 bg-amber-500/5 rounded-full blur-2xl" />

        {/* Header decoration logo */}
        <div className="text-center mb-8">
          <div className="mx-auto p-3 bg-amber-400/10 text-amber-400 rounded-2xl w-fit border border-amber-400/20 mb-4">
            <GraduationCap className="h-6 w-6 stroke-[2]" />
          </div>
          <h2 className="text-2xl font-sans font-extrabold text-white tracking-tight">
            {isReset ? 'Password Reset Options' : isSignUp ? 'Create Corporate Account' : 'Secure Member Login'}
          </h2>
          <p className="text-xs text-gray-450 mt-1">
            {isReset 
              ? 'Enter email associated with your LMS account' 
              : isSignUp 
              ? 'Register with Blockchain Verification access' 
              : 'Enter credential criteria to access lessons'}
          </p>
        </div>

        {/* Input Form */}
        <form onSubmit={handleValidationAndSubmit} className="space-y-4">
          
          {isSignUp && !isReset && (
            <div>
              <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Full Name</label>
              <div className="relative">
                <User className="absolute left-3 top-3.5 h-4 w-4 text-gray-500" />
                <input 
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar"
                  className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white font-sans"
                />
              </div>
            </div>
          )}

          <div>
            <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Member Email Address</label>
            <div className="relative">
              <Mail className="absolute left-3 top-3.5 h-4 w-4 text-gray-500" />
              <input 
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="e.g. ramesh@example.com"
                className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white font-mono"
              />
            </div>
          </div>

          {!isReset && (
            <div>
              <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Account Password</label>
              <div className="relative">
                <Lock className="absolute left-3 top-3.5 h-4 w-4 text-gray-500" />
                <input 
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl pl-10 pr-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white font-mono"
                />
              </div>
            </div>
          )}

          {isSignUp && !isReset && (
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Core Domain</label>
                <select 
                  value={branch}
                  onChange={(e) => setBranch(e.target.value)}
                  className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl p-3 text-xs focus:outline-none text-white"
                >
                  <option value="electrical">Electrical EE</option>
                  <option value="mechanical">Mechanical ME</option>
                  <option value="civil">Civil CE</option>
                  <option value="electronics">Electronics</option>
                  <option value="ec">EC Telecom</option>
                  <option value="computer">Computer CSE</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Seniority Grade</label>
                <select 
                  value={role}
                  onChange={(e) => setRole(e.target.value as UserRole)}
                  className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl p-3 text-xs focus:outline-none text-white"
                >
                  <option value="fresher">🎓 Fresher Track</option>
                  <option value="experienced">💼 Experienced Track</option>
                  <option value="manager">🧑‍💼 Manager Track</option>
                </select>
              </div>
            </div>
          )}

          {/* Validation indicators */}
          {errorText && (
            <div className="p-3 bg-red-950/20 border border-red-900/50 text-red-400 text-xs rounded-xl flex gap-2 items-center font-mono">
              <AlertCircle className="h-4 w-4 shrink-0" />
              <span>{errorText}</span>
            </div>
          )}

          {successText && (
            <div className="p-3 bg-emerald-950/20 border border-emerald-900/50 text-emerald-300 text-xs rounded-xl flex gap-2 items-center font-mono">
              <CheckCircle className="h-4 w-4 shrink-0" />
              <span>{successText}</span>
            </div>
          )}

          {/* Action Trigger */}
          <button
            type="submit"
            className="w-full py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-black rounded-xl text-xs uppercase tracking-wide shadow-md transition-all cursor-pointer flex justify-center items-center gap-1"
          >
            <span>
              {isReset ? 'Dispatched Password Code' : isSignUp ? 'Generate Blockchain Credentials' : 'Secure Sign In'}
            </span>
            <ChevronRight className="h-4 w-4" />
          </button>
        </form>

        {/* Option toggling controls */}
        <div className="mt-6 pt-5 border-t border-gray-800 text-xs text-center flex flex-wrap justify-between gap-3 text-gray-450 font-mono">
          {isReset ? (
            <button 
              onClick={() => setIsReset(false)}
              className="text-amber-400 hover:underline mx-auto block cursor-pointer"
            >
              ← Back to login options
            </button>
          ) : (
            <>
              <button 
                onClick={() => { setIsSignUp(!isSignUp); setErrorText(''); setSuccessText(''); }}
                className="text-gray-300 hover:text-white transition-colors cursor-pointer"
              >
                {isSignUp ? "Already have an account? Sign In" : "Need registration? Click here"}
              </button>
              <button 
                onClick={() => { setIsReset(true); setErrorText(''); setSuccessText(''); }}
                className="text-amber-400 hover:underline cursor-pointer"
              >
                Forgot Password?
              </button>
            </>
          )}
        </div>

      </div>
    </div>
  );
}
