import { UserRole, ViewState } from '../types';
import { 
  Users, 
  HelpCircle, 
  Award, 
  Calendar, 
  CheckCircle, 
  ArrowLeft, 
  ArrowRight, 
  MessageSquare, 
  Phone, 
  Video, 
  Flame, 
  FileText,
  BadgeAlert,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';
import { motion } from 'motion/react';
import { BRANCHES_DATA } from '../data/courses';

interface AudienceTrackProps {
  audience: UserRole;
  setView: (view: ViewState) => void;
}

export default function AudienceTrack({ audience, setView }: AudienceTrackProps) {
  
  const getAudienceData = () => {
    switch (audience) {
      case 'fresher':
        return {
          title: 'Freshers Track Programme',
          tagline: 'Your Engineering Degree + Our PG = Your Dream Job',
          description: 'Designed exclusively for early graduates (0–2 yrs exp) seeking placements in premium core domains. Master raw practical engineering & process tools before hiring drives.',
          highlights: [
            { title: 'Personal Direct Placement Manager', text: 'Daily alerts, resume refinement & custom LinkedIn branding.' },
            { title: 'Aptitude & Technical Domain Coaching', text: 'Syllabus tests designed to crack multinational criteria.' },
            { title: '3-Rounds Mock Panel Practice', text: 'Run mock drills with experienced engineers before active drives.' },
            { title: 'Easy Zero-Interest EMI & Scholarships', text: 'Flexible payment option templates with low monthly overheads.' }
          ],
          syllabusPreview: 'Full-stack fundamentals, Matlab simulations, basic hardware board diagnostics, AutoCAD blueprinting, and standard Green Belt Lean statistics.',
          ctaText: 'Apply for Fresher Batch (Assured Placement)',
          accentClass: 'from-blue-500/20 to-indigo-600/5 border-blue-500/30 text-blue-400'
        };
      case 'experienced':
        return {
          title: 'Experienced Track Programme',
          tagline: 'Upgrade Your Skills — Get the Promotion You Deserve',
          description: 'For working professionals (2–10 yrs exp) aiming for corporate promotions, domain switches, or technology specialization. Built for zero career disruption.',
          highlights: [
            { title: 'Strictly Weekend-Only Batches', text: 'Live interactive classes on Saturdays & Sundays. Zero interference with job tasks.' },
            { title: 'Industry 4.0 & Advanced Industrial AI', text: 'Master modern asset digital twins, predictive algorithms & deep modeling.' },
            { title: 'Seamless Domain-Switch Paths', text: 'Clear roadmap blueprints to transition safely from field/site tasks to core designs.' },
            { title: 'Salary Increment Strategic Negotiation', text: 'Personal executive coaching to maximize your offer percentages.' }
          ],
          syllabusPreview: 'Advanced EV technologies, 4-Layer board designs, STAAD earthquake designs, Siemens NX digital twins, and Black Belt DMAIC diagnostics.',
          ctaText: 'Schedule Free Career Counselling Session',
          accentClass: 'from-amber-500/20 to-yellow-600/5 border-amber-500/30 text-amber-400'
        };
      case 'manager':
        return {
          title: 'Managers & Executive Leadership Track',
          tagline: 'From Engineer to Leader — Command Your Industry',
          description: 'For senior engineers, leads, supervisors and managers (10+ yrs exp) targeting global CXO or Operational Excellence directorship positions.',
          highlights: [
            { title: 'Elite Executive CXO Networking', text: 'Join virtual cohort dinners, trade roundtables & direct headhunter networks.' },
            { title: 'Company/Corporate Sponsored Paths', text: 'Syllabus is HR compliance-ready. Includes complete grant documentation templates.' },
            { title: 'AI Leadership Strategy, P&L & NetZero', text: 'Master global resource budgeting, carbon tax frameworks, and strategic lean operations.' },
            { title: '1-on-1 Executive Career Mentoring', text: 'Weekly checkpoint calls with experienced multinational operating directors.' }
          ],
          syllabusPreview: 'Global P&L structures, Industry 5s standards, carbon footprint tracking models, executive risk frameworks, and Agile product scaling.',
          ctaText: 'Request Executive Brochure & 1-on-1 Call',
          accentClass: 'from-emerald-500/20 to-teal-600/5 border-emerald-500/30 text-emerald-400'
        };
    }
  };

  const data = getAudienceData();

  const handleApplyClick = () => {
    // Navigate directly to standard checkout for the customized category
    const price = audience === 'fresher' ? 45000 : audience === 'experienced' ? 85000 : 98000;
    setView({
      type: 'checkout',
      plan: {
        name: `${data.title} - Comprehensive Syllabus`,
        price,
        type: audience === 'fresher' ? 'Certificate' : 'Advanced Professional Diploma'
      }
    });
  };

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 py-12" id="audience-track-root">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Back navigation */}
        <button 
          onClick={() => setView({ type: 'home' })}
          className="inline-flex items-center space-x-2 text-xs text-gray-400 hover:text-amber-400 font-mono transition-colors mb-8 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Landing Dashboard</span>
        </button>

        {/* Hero Area */}
        <div className={`p-8 lg:p-12 rounded-3xl bg-gradient-to-br ${data.accentClass} border relative overflow-hidden mb-12`}>
          <div className="relative z-10 max-w-3xl">
            <span className="font-mono text-xs uppercase font-extrabold px-3 py-1 rounded bg-black/40 border border-gray-800 text-amber-300">
              AUDIENCE TRACK SPECIFICATION
            </span>
            <h1 className="text-3xl sm:text-5xl font-sans font-extrabold text-white mt-4 tracking-tight leading-tight">
              {data.title}
            </h1>
            <p className="text-lg sm:text-xl font-medium text-white italic mt-2 border-l-2 border-amber-400 pl-4 py-1">
              "{data.tagline}"
            </p>
            <p className="text-xs sm:text-sm text-gray-300 mt-4 leading-relaxed font-sans">
              {data.description}
            </p>

            <div className="mt-8 flex flex-wrap gap-4">
              <button 
                onClick={handleApplyClick}
                className="px-6 py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-extrabold rounded-xl text-xs sm:text-sm tracking-wide uppercase transition-all shadow-lg text-center cursor-pointer shadow-amber-500/10"
              >
                {data.ctaText}
              </button>
              
              <a 
                href="https://wa.me/1234567890" 
                target="_blank" 
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-5 py-3 border border-emerald-500/25 bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-xs sm:text-sm font-bold rounded-xl transition-all"
              >
                <MessageSquare className="h-4 w-4 fill-emerald-300 text-transparent" />
                <span>Simulate WhatsApp Quick Chat</span>
              </a>
            </div>
          </div>
          
          <div className="absolute right-6 top-6 opacity-10 hidden lg:block">
            <Users className="h-48 w-48 text-white stroke-[1.2]" />
          </div>
        </div>

        {/* Highlights Grid */}
        <div className="mb-16">
          <h2 className="text-2xl font-sans font-bold text-white mb-8 flex items-center gap-2">
            <Award className="h-6 w-6 text-amber-400" /> Key Features & Guaranteed Milestones
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {data.highlights.map((hl, idx) => (
              <div key={idx} className="bg-gray-900/60 p-6 border border-gray-800 rounded-2xl">
                <h3 className="font-sans font-bold text-white text-base flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-400 shrink-0" />
                  <span>{hl.title}</span>
                </h3>
                <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                  {hl.text}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Core Syllabus Track Summary block */}
        <div className="bg-gray-950 p-8 border border-gray-850 rounded-3xl mb-16">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-center">
            <div className="lg:col-span-1">
              <span className="font-mono text-[10px] text-amber-400 font-bold tracking-wider block">CURRICULUM ARCHITECTURE</span>
              <h3 className="text-xl font-bold text-white mt-1">Foundational Frameworks Included</h3>
              <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                Unlock structured modules tailored directly to your seniority. Check out our branch views for full year-long syllabi detailing tools, project specs & expert trainers.
              </p>
            </div>
            <div className="lg:col-span-2 p-5 bg-gray-900 border border-gray-800 rounded-xl font-mono text-xs text-gray-300 relative">
              <div className="absolute right-3 top-3 text-[10px] bg-amber-400/10 text-amber-400 px-2 py-0.5 rounded uppercase font-semibold">Active Profile Preview</div>
              <strong className="text-white block mb-2">Subject Matrix Covered:</strong>
              <p className="leading-relaxed leading-normal">{data.syllabusPreview}</p>
            </div>
          </div>
        </div>

        {/* Branches available list */}
        <div>
          <h2 className="text-xl font-sans font-bold text-white mb-6">Select an Specialisation Branch to view detailed tabbed parameters</h2>
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            {BRANCHES_DATA.map(b => (
              <button 
                key={b.id}
                onClick={() => setView({ type: 'branch', branchId: b.id })}
                className="p-4 bg-gray-900 border border-gray-800 hover:border-amber-400/50 rounded-xl transition-all hover:scale-[1.03] text-left group cursor-pointer"
              >
                <div className="text-base font-bold text-white group-hover:text-amber-300 transition-colors truncate">{b.name.split(' ')[0]}</div>
                <div className="text-[10px] text-amber-400 font-mono mt-1">View Details →</div>
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
}
