import React, { useState, useEffect, useRef } from 'react';
import { UserSession } from '../types';
import { 
  X, 
  Send, 
  Sparkles, 
  Cpu, 
  HelpCircle, 
  CheckCircle,
  TrendingUp,
  MessageSquare,
  BookOpen
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AITutorChatProps {
  isOpen: boolean;
  onClose: () => void;
  session: UserSession;
}

export default function AITutorChat({ isOpen, onClose, session }: AITutorChatProps) {
  const [messages, setMessages] = useState<Array<{ sender: 'user' | 'tutor'; text: string }>>([
    { sender: 'tutor', text: `Greetings ${session.user?.name || 'Engineer'}! I am Sixsigma AI, your engineering companion mentor. Which domain parameter are you working on today? (Electrical, MATLAB, Six Sigma FMEA, STAAD.Pro structure, or Altium PCBs?)` }
  ]);
  const [inputVal, setInputVal] = useState('');
  const [isReplying, setIsReplying] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (messagesEndRef.current) {
      messagesEndRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isReplying]);

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputVal.trim()) return;

    const userText = inputVal;
    setMessages(prev => [...prev, { sender: 'user', text: userText }]);
    setInputVal('');
    setIsReplying(true);

    setTimeout(() => {
      let reply = `Based on the Sixsigma AI engineering curriculum, that formula is crucial. `;
      
      const query = userText.toLowerCase();
      if (query.includes('formula') || query.includes('matlab') || query.includes('equation')) {
        reply = `To calculate standard microgrid load variables in MATLAB:
1. Define your current state matrix.
2. Build discrete system matrices using standard state space formulation.
3. Apply standard voltage thresholds to trigger isolated grids.`;
      } else if (query.includes('six sigma') || query.includes('dmaic') || query.includes('belt')) {
        reply = `Our Six Sigma DMAIC guidelines dictate that any process optimization must begin with defining the CTQ (Critical-To-Quality) tree. Ensure that your FMEA (Failure Mode and Effects Analysis) tables list specific failure modes with an RPN (Risk Priority Number) higher than 100 before applying corrective actions.`;
      } else if (query.includes('pcb') || query.includes('altium') || query.includes('electronics')) {
        reply = `For standard 4-layer PCB configurations in Altium Designer:
- Place your ground plane adjacent to signal layer-1.
- Maintain a continuous return path to eliminate EMI loop antennas.
- Match high-speed differential signal track lengths to avoid signal skew.`;
      } else if (query.includes('bim') || query.includes('revit') || query.includes('civil')) {
        reply = `For standard Revit BIM configurations:
- Check that all structural elements (STAAD.Pro wind load profiles) align with spatial grids.
- Ensure Navisworks clash reports are zero before publishing design formats.`;
      }

      setMessages(prev => [...prev, { sender: 'tutor', text: reply }]);
      setIsReplying(false);
    }, 1200);
  };

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div 
          initial={{ opacity: 0, x: 100 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: 100 }}
          className="fixed right-4 bottom-4 z-50 w-full max-w-sm bg-gray-950 border border-gray-800 rounded-2xl shadow-2xl flex flex-col h-[500px]"
          id="ai-tutor-drawer"
        >
          {/* Header */}
          <div className="bg-gradient-to-r from-[#0F1626] to-gray-950 p-4 border-b border-gray-850 flex justify-between items-center rounded-t-2xl">
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-amber-400/10 text-amber-400 rounded-lg border border-amber-400/20">
                <Sparkles className="h-4 w-4 animate-pulse" />
              </div>
              <div>
                <h4 className="font-sans font-bold text-white text-xs leading-none">Sixsigma AI</h4>
                <span className="text-[9px] text-[#A3B1CC] font-mono leading-none">24x7 Academic Assistant</span>
              </div>
            </div>
            <button 
              onClick={onClose}
              className="p-1.5 hover:bg-gray-850 text-gray-500 hover:text-white rounded-lg transition-colors cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Messages list */}
          <div className="flex-grow overflow-y-auto p-4 space-y-3.5 text-xs font-mono">
            {messages.map((m, idx) => (
              <div 
                key={idx}
                className={`p-3 rounded-xl leading-normal ${
                  m.sender === 'user'
                    ? 'bg-amber-400/10 text-amber-300 border border-amber-500/20 text-right ml-6'
                    : 'bg-gray-900 text-gray-200 border border-gray-850 mr-6'
                }`}
              >
                {m.text}
              </div>
            ))}
            {isReplying && (
              <div className="text-gray-500 italic animate-pulse">Assistant compiling parameters...</div>
            )}
            <div ref={messagesEndRef} />
          </div>

          {/* Input Panel footer */}
          <form onSubmit={handleSendMessage} className="p-3.5 border-t border-gray-850 bg-gray-950 flex gap-2 rounded-b-2xl">
            <input 
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="Ask formula (e.g. PCB return path limits)"
              className="flex-grow bg-[#0E1321] border border-gray-800 focus:border-amber-400 px-3 py-2 text-xs rounded-xl text-white focus:outline-none"
            />
            <button
              type="submit"
              className="p-2.5 bg-amber-400 hover:bg-amber-500 text-gray-950 rounded-xl transition-colors cursor-pointer shrink-0"
            >
              <Send className="h-4 w-4 fill-gray-950" />
            </button>
          </form>

        </motion.div>
      )}
    </AnimatePresence>
  );
}
