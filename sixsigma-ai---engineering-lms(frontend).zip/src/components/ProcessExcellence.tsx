import { ViewState } from '../types';
import { 
  ArrowLeft, 
  Award, 
  Layers, 
  CheckCircle2, 
  Wrench, 
  HelpCircle, 
  BarChart, 
  BookOpen, 
  TrendingUp, 
  Gauge, 
  GitBranch, 
  Flame, 
  ChevronRight,
  ShieldCheck
} from 'lucide-react';
import { motion } from 'motion/react';

interface ProcessExcellenceProps {
  progId: 'six-sigma' | 'kaizen' | '5s';
  setView: (view: ViewState) => void;
}

export default function ProcessExcellence({ progId, setView }: ProcessExcellenceProps) {
  
  const getProgData = () => {
    switch (progId) {
      case 'six-sigma':
        return {
          title: 'Six Sigma Excellence Programme',
          badge: 'Sixsigma AI Internationally Recognized Certifications',
          accent: 'from-amber-400 to-amber-600 text-amber-400 border-amber-500/30',
          desc: 'Comprehensive methodologies focused on process parameters, eliminating defect variables and streamlining manufacturing. We cover White Belt to Master Black Belt certification verified via blockchain.',
          levels: [
            { name: 'White Belt — Awareness (1 Day)', audience: 'Beginners & General Support Employees', syllabus: 'Basic introduction, core concepts, Lean terminology.' },
            { name: 'Yellow Belt — Foundation (3 Days)', audience: 'Project Team Members & Operations', syllabus: 'PDCA loops, raw statistics, standard deviation basics.' },
            { name: 'Green Belt — Practitioner (4 Weeks)', audience: 'Engineers, Quality Leads & Supervisors', syllabus: 'DMAIC methodology, SPC chart calculations, Gauge R&R, FMEA tables.' },
            { name: 'Black Belt — Expert (3 Months)', audience: 'Technical Operations & Specialists', syllabus: 'DMADV process, Design of Experiments (DOE), Multivariate regression, Minitab sandboxes.' },
            { name: 'Master Black Belt — Leadership (6 Months)', audience: 'CXOs, Quality Directors & Lead Consultants', syllabus: 'Global portfolio budgeting, corporate upskilling plans, statistical compliance.' }
          ],
          outcomes: ['Reduce failure rate variables below 3.4 ppm', 'Implement deep statistical calculations using Minitab', 'Establish control loops across raw industrial assemblies'],
          tools: ['Minitab', 'Excel Statistics Solver', 'FMEA Dashboards', 'SIGMA Calculator']
        };
      case 'kaizen':
        return {
          title: 'Kaizen & Continuous Improvement',
          badge: 'Shopfloor Speed Optimization Blueprint',
          accent: 'from-blue-500 to-indigo-600 text-blue-400 border-blue-500/30',
          desc: 'Learn continuous speed adaptation. Master rapid event workshops (Gemba Walks) and Value Stream Mapping layouts to eliminate corporate and factory assembly overheads.',
          levels: [
            { name: 'Kaizen Fundamentals Mindset', audience: 'All Employees & Early-Career Grads', syllabus: 'Wastes tracking (Muda, Mura, Muri), PDCA execution.' },
            { name: 'Rapid Improvement Workshop (5 Days)', audience: 'Manufacturing Supervisors & Operations', syllabus: 'GEMBA walks, workstation space mapping, cycle reduction pilots.' },
            { name: 'Value Stream Mapping (VSM)', audience: 'Supply Chain Leads & Operations Managers', syllabus: 'Draw current-state maps, analyze bottleneck delays, build model future-states.' },
            { name: 'Kaizen Leader Certification', audience: 'Plant Directors & Consultancies managers', syllabus: 'Motivating shopfloor groups, tracking daily performance indicators.' }
          ],
          outcomes: ['Eliminate non-value-added processes completely', 'Improve Overall Equipment Effectiveness (OEE) metrics', 'Motivate shopfloor employees with micro reward trackers'],
          tools: ['VSM Studio', 'Gemba Walk Checklists', 'Time-Motion Study tools', 'OEE Dashboard']
        };
      case '5s':
        return {
          title: '5S Workplace Organisation System',
          badge: 'Safe, Highly Productive Spatial Layouts',
          accent: 'from-emerald-500 to-teal-600 text-emerald-400 border-emerald-500/30',
          desc: 'Establish safety, compliance and pristine visual management systems. Standardize layout rules to elevate workplace metrics and optimize raw catalog storage space.',
          levels: [
            { name: '5S Foundations Certification', audience: 'Pristine Warehouse Operators & Leads', syllabus: 'The 5 Pillars: Sort (Seiri), Set in Order (Seiton), Shine (Seiso), Standardize (Seiketsu), Sustain (Shitsuke).' },
            { name: '5S Implementation Workshop (2 Days)', audience: 'Supervisors & Workspace Managers', syllabus: 'Organize warehouse visual labels, design border lines, execute audit score sheets.' },
            { name: '5S Professional Auditor License', audience: 'Auditors & Compliance Officers', syllabus: 'Establish weekly audit sheets, analyze performance indicators, maintain safety metrics.' },
            { name: '5S + Visual Management Advanced', audience: 'LMS Managers & Quality directors', syllabus: 'Integrating IoT proximity sensors, digital labeling systems.' }
          ],
          outcomes: ['Safeguard warehouse protocols against common accidents', 'Standardize high-density storage access speed', 'Formulate active weekly reporting audit scores'],
          tools: ['5S Audit Pro app', 'Visual Tape layout models', 'Red Label Sandbox', 'Safety reporting sheets']
        };
    }
  };

  const data = getProgData();

  const handleEnrollClick = () => {
    setView({
      type: 'checkout',
      plan: {
        name: `${data.title} - Full Certification Pack`,
        price: 35000,
        type: 'Process Certificate'
      }
    });
  };

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 py-12" id="process-excellence-root">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Back navigation */}
        <button 
          onClick={() => setView({ type: 'home' })}
          className="inline-flex items-center space-x-2 text-xs text-gray-400 hover:text-amber-400 font-mono transition-colors mb-8 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Landing dashboard</span>
        </button>

        {/* Hero Area */}
        <div className={`p-8 sm:p-12 bg-gradient-to-br from-gray-900 to-gray-955 border rounded-3xl relative overflow-hidden mb-12 ${data.accent}`}>
          <div className="relative z-10 max-w-3xl">
            <span className="font-mono text-xs uppercase font-extrabold px-3 py-1 bg-black/45 rounded border text-amber-300">
              {data.badge}
            </span>
            <h1 className="text-3xl sm:text-5xl font-sans font-extrabold text-white mt-4 tracking-tight leading-tight">
              {data.title}
            </h1>
            <p className="text-xs sm:text-sm text-gray-300 mt-4 leading-relaxed">
              {data.desc}
            </p>

            <button 
              onClick={handleEnrollClick}
              className="mt-8 px-6 py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-extrabold rounded-xl text-xs sm:text-sm uppercase tracking-wider shadow-lg shadow-amber-500/5 cursor-pointer"
            >
              Enroll & Start Continuous Pilot
            </button>
          </div>
        </div>

        {/* Major structure columns */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          
          {/* Levels Syllabus list columns */}
          <div className="lg:col-span-2 space-y-6">
            <h2 className="text-xl font-sans font-extrabold text-white mb-6 flex items-center gap-2">
              <Layers className="h-5 w-5 text-amber-400" /> Syllabus Modules & Seniority levels
            </h2>

            <div className="space-y-4">
              {data.levels.map((lvl, idx) => (
                <div key={idx} className="p-5 bg-gray-900/60 border border-gray-850 rounded-xl relative overflow-hidden">
                  <span className="p-1 px-1.5 bg-gray-850 text-[9px] font-mono rounded font-bold text-amber-400">STAGE Level #{idx + 1}</span>
                  <h4 className="font-sans font-extrabold text-white text-sm mt-2.5">{lvl.name}</h4>
                  
                  <div className="text-xs text-gray-450 mt-1">
                    Target audience: <strong className="text-gray-300">{lvl.audience}</strong>
                  </div>
                  <p className="text-xs text-gray-405 leading-relaxed mt-2 pl-3 border-l border-amber-400/25">
                    {lvl.syllabus}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Sidebar parameters */}
          <div className="space-y-6">
            
            {/* Project outcomes checklist */}
            <div className="p-6 bg-gradient-to-b from-gray-900 to-gray-950 border border-gray-850 rounded-2xl">
              <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-4 flex items-center gap-1.5">
                <ShieldCheck className="h-4 w-4 text-emerald-400" /> Measurable Outcomes
              </h4>

              <ul className="space-y-4 text-xs text-gray-300">
                {data.outcomes.map((out, idx) => (
                  <li key={idx} className="flex gap-2 leading-relaxed">
                    <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                    <span>{out}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Quality tools */}
            <div className="p-6 bg-gray-900/40 border border-gray-850 rounded-2xl">
              <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-4 flex items-center gap-1.5">
                <Wrench className="h-4 w-4 text-blue-400" /> Core Tools Leveraged
              </h4>

              <div className="flex flex-wrap gap-2">
                {data.tools.map((tool, idx) => (
                  <span key={idx} className="text-xs bg-gray-900 border border-gray-800 px-3 py-1 text-gray-300 rounded font-medium font-mono">
                    {tool}
                  </span>
                ))}
              </div>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
