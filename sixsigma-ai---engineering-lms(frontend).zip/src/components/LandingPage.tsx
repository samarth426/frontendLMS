import { UserRole, ViewState } from '../types';
import { 
  Zap, 
  Settings, 
  Home, 
  Cpu, 
  Radio, 
  Laptop, 
  TrendingUp, 
  ShieldCheck, 
  ArrowRight, 
  Briefcase, 
  Award, 
  Users, 
  Play, 
  ChevronRight, 
  CheckCircle2, 
  Star,
  FileSpreadsheet,
  Gauge
} from 'lucide-react';
import { motion } from 'motion/react';
import { BRANCHES_DATA, TESTIMONIALS, RECRUITERS, PLACEMENT_STATS } from '../data/courses';

interface LandingPageProps {
  setView: (view: ViewState) => void;
}

export default function LandingPage({ setView }: LandingPageProps) {
  
  const getBranchIcon = (iconName: string) => {
    switch (iconName) {
      case 'Zap': return <Zap className="h-6 w-6" />;
      case 'Settings': return <Settings className="h-6 w-6" />;
      case 'Home': return <Home className="h-6 w-6" />;
      case 'Cpu': return <Cpu className="h-6 w-6" />;
      case 'Radio': return <Radio className="h-6 w-6" />;
      case 'Laptop': return <Laptop className="h-6 w-6" />;
      default: return <Settings className="h-6 w-6" />;
    }
  };

  const handleAudienceClick = (role: UserRole) => {
    setView({ type: 'programmes', audience: role });
  };

  const handleBranchClick = (branchId: string) => {
    setView({ type: 'branch', branchId });
  };

  return (
    <div className="bg-[#080C14] text-gray-100 min-h-screen" id="landing-page-root">
      
      {/* 1. Placement Ticker Bar */}
      <div className="bg-gradient-to-r from-amber-500/10 via-amber-400/20 to-amber-600/10 border-y border-amber-500/30 overflow-hidden py-3" id="placement-ticker">
        <div className="max-w-7xl mx-auto px-4 flex flex-wrap justify-between items-center text-xs sm:text-sm font-mono text-amber-300 font-semibold gap-3">
          <div className="flex items-center space-x-2">
            <TrendingUp className="h-4 w-4 text-emerald-400 animate-pulse" />
            <span>🔥 LIVE DASHBOARD ACCREDITATION</span>
          </div>
          <div className="flex items-center space-x-4 divide-x divide-amber-500/30">
            <span className="pl-4">🚀 5000+ Alumni Placed Across 15+ Countries</span>
            <span className="pl-4">📈 85%+ Placement Rate within 6 Months</span>
            <span className="pl-4">💼 CTC Range: ₹3.5 LPA - ₹25 LPA</span>
          </div>
        </div>
      </div>

      {/* 2. Hero Section */}
      <section className="relative overflow-hidden py-24 lg:py-32" id="hero-section">
        {/* Abstract futuristic grid background decoration */}
        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top_right,rgba(245,158,11,0.06),transparent_50%)]" />
        <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.01)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.01)_1px,transparent_1px)] bg-[size:40px_40px]" />
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="text-center max-w-4xl mx-auto">
            
            <motion.div 
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-400 text-xs font-mono font-bold uppercase tracking-widest mb-6"
            >
              <Award className="h-3.5 w-3.5 text-amber-400" />
              <span>Sixsigma AI International Accreditation</span>
            </motion.div>

            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="font-sans font-extrabold text-4xl sm:text-6xl text-white tracking-tight leading-tight"
            >
              Become an Industry-Ready Engineer<br />
              <span className="bg-gradient-to-r from-amber-400 via-amber-300 to-amber-100 bg-clip-text text-transparent">
                PG Programmes for All Branches
              </span>
            </motion.h1>

            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              className="mt-6 text-lg sm:text-xl text-gray-350 max-w-2xl mx-auto leading-relaxed border-l-2 border-amber-500/50 pl-4 py-1 italic"
            >
              ✔ PG Certificate 6M &nbsp;│&nbsp; ✔ Advanced Diploma 1Yr &nbsp;│&nbsp; AI-Augmented Placement Guarantee
            </motion.p>

            {/* Audience Track CTAs */}
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl mx-auto"
            >
              <button 
                onClick={() => handleAudienceClick('fresher')}
                className="flex flex-col items-center justify-between p-6 bg-gradient-to-b from-gray-900 to-gray-950 border border-gray-800 hover:border-amber-400/50 rounded-2xl transition-all hover:scale-[1.02] text-left group cursor-pointer shadow-lg hover:shadow-amber-500/5"
              >
                <div className="flex items-center justify-between w-full mb-3">
                  <span className="p-2.5 bg-blue-500/10 text-blue-400 rounded-xl font-bold text-lg">🎓</span>
                  <ArrowRight className="h-4 w-4 text-gray-500 group-hover:text-amber-400 group-hover:translate-x-1 transition-all" />
                </div>
                <div className="w-full text-left">
                  <h3 className="font-sans font-bold text-white text-base">I am a Fresher</h3>
                  <p className="text-xs text-gray-400 mt-1">Beginner Track (0-2 Yrs). Resume building & Core placements assured.</p>
                </div>
              </button>

              <button 
                onClick={() => handleAudienceClick('experienced')}
                className="flex flex-col items-center justify-between p-6 bg-gradient-to-b from-gray-900 to-gray-950 border border-gray-800 hover:border-amber-400/50 rounded-2xl transition-all hover:scale-[1.02] text-left group cursor-pointer shadow-lg hover:shadow-amber-500/5"
              >
                <div className="flex items-center justify-between w-full mb-3">
                  <span className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl font-bold text-lg">💼</span>
                  <ArrowRight className="h-4 w-4 text-gray-500 group-hover:text-amber-400 group-hover:translate-x-1 transition-all" />
                </div>
                <div className="w-full text-left">
                  <h3 className="font-sans font-bold text-white text-base">I am Experienced</h3>
                  <p className="text-xs text-gray-400 mt-1">Skill Upgrade (2-10 Yrs). Domain Switch & Weekend lectures.</p>
                </div>
              </button>

              <button 
                onClick={() => handleAudienceClick('manager')}
                className="flex flex-col items-center justify-between p-6 bg-gradient-to-b from-gray-900 to-gray-950 border border-amber-500/30 hover:border-amber-400 rounded-2xl transition-all hover:scale-[1.02] text-left group cursor-pointer shadow-lg shadow-amber-500/5"
              >
                <div className="flex items-center justify-between w-full mb-3">
                  <span className="p-2.5 bg-emerald-500/10 text-emerald-400 rounded-xl font-bold text-lg">🧑‍💼</span>
                  <ArrowRight className="h-4 w-4 text-amber-400 group-hover:translate-x-1 transition-all" />
                </div>
                <div className="w-full text-left">
                  <h3 className="font-sans font-bold text-white text-base flex items-center justify-between">
                    <span>I am a Manager</span>
                    <span className="text-[10px] bg-amber-400/15 text-amber-300 font-mono px-1.5 py-0.5 rounded">CXO</span>
                  </h3>
                  <p className="text-xs text-gray-400 mt-1">Core Leadership (10+ Yrs). Industry 4.5, NetZero & P&L Decision model.</p>
                </div>
              </button>
            </motion.div>

            {/* Quick Consultation CTAs */}
            <div className="mt-10 flex flex-wrap justify-center gap-12 text-sm text-gray-400 font-mono">
              <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-amber-500" /> Book Free Counseling</span>
              <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-emerald-500" /> WhatsApp Direct Chat Support</span>
              <span className="flex items-center gap-2"><CheckCircle2 className="h-4 w-4 text-blue-500" /> Download Brochure PDF</span>
            </div>

          </div>
        </div>
      </section>

      {/* 3. Branch Selector Grid */}
      <section className="py-20 bg-gray-950/60 border-t border-gray-900" id="branch-selector">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl font-sans font-bold text-white tracking-tight">
              Select Your Engineering Domain
            </h2>
            <p className="text-gray-400 mt-2 text-sm">
              We cover all core branches with specialized industry applications, diagnostic labs, and AI modules.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {BRANCHES_DATA.map((branch) => (
              <div 
                key={branch.id}
                onClick={() => handleBranchClick(branch.id)}
                className="bg-gray-900 border border-gray-800 hover:border-amber-400/50 rounded-2xl p-6 transition-all duration-300 hover:scale-[1.01] group cursor-pointer shadow-md flex flex-col justify-between"
              >
                <div>
                  <div className={`p-3 bg-gradient-to-br ${branch.color} text-gray-950 rounded-xl w-fit mb-5 shadow-md`}>
                    {getBranchIcon(branch.icon)}
                  </div>
                  <h3 className="text-xl font-bold text-white group-hover:text-amber-300 transition-colors">
                    {branch.name}
                  </h3>
                  <p className="text-xs text-gray-400 mt-2 line-clamp-2">
                    {branch.description}
                  </p>
                </div>

                <div className="mt-6 pt-5 border-t border-gray-800 flex items-center justify-between text-xs">
                  <div className="space-y-1 text-[11px] text-gray-400">
                    <div className="flex items-center gap-1">
                      <span className="text-amber-400">⚡</span>
                      <span>{branch.certificate6m.fee.split('|')[0]}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <span className="text-emerald-400">🎓</span>
                      <span>Graduation placements assured</span>
                    </div>
                  </div>
                  <span className="text-amber-400 font-bold group-hover:translate-x-1.5 transition-transform flex items-center gap-1 font-mono">
                    View Tracks <ChevronRight className="h-4 w-4" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Process Excellence Section */}
      <section className="py-20 border-t border-gray-900" id="process-excellence-features">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-br from-[#0F1626] to-gray-950 border border-amber-500/25 rounded-3xl p-8 lg:p-12 relative overflow-hidden">
            <div className="absolute right-0 top-0 h-40 w-40 bg-amber-500/10 rounded-full blur-3xl" />
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
              <div>
                <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-widest bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
                  Global Gold Standard
                </span>
                <h2 className="text-3xl sm:text-4xl font-sans font-extrabold text-white tracking-tight mt-4">
                  Process Excellence Programmes
                </h2>
                <p className="text-gray-300 mt-4 text-sm leading-relaxed">
                  Every modern engineering sector needs Kaizen, Lean operations, and statistical quality audits. We provide internationally recognized certifications verified via Blockchain that empower engineers to eliminate shopfloor waste & optimize P&L overheads.
                </p>

                <div className="mt-8 space-y-4">
                  <div className="flex gap-3">
                    <span className="p-1 px-2 bg-amber-500/25 rounded font-bold text-amber-300 text-xs font-mono">75%</span>
                    <div>
                      <h4 className="font-bold text-white text-sm">Six Sigma Practitioner Tracks</h4>
                      <p className="text-xs text-gray-400">White Belt, Yellow Belt, Green Belt, and Master Black Belt with real industry Minitab calculations exercises.</p>
                    </div>
                  </div>

                  <div className="flex gap-3">
                    <span className="p-1 px-2 bg-emerald-500/25 rounded font-bold text-emerald-300 text-xs font-mono">VSM</span>
                    <div>
                      <h4 className="font-bold text-white text-sm">Kaizen & 5S Organisation Systems</h4>
                      <p className="text-xs text-gray-400">Transform traditional warehouses and shopfloors into hyper-safe workspace layouts utilizing visual metrics systems.</p>
                    </div>
                  </div>
                </div>

                <div className="mt-10 flex gap-4">
                  <button 
                    onClick={() => setView({ type: 'process-excellence', progId: 'six-sigma' })}
                    className="px-5 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-bold rounded-lg text-xs tracking-wide uppercase transition-all shadow-md shadow-amber-500/10 cursor-pointer"
                  >
                    Six Sigma Belts
                  </button>
                  <button 
                    onClick={() => setView({ type: 'process-excellence', progId: 'kaizen' })}
                    className="px-5 py-2.5 border border-gray-800 hover:border-gray-500 text-gray-350 font-bold rounded-lg text-xs transition-colors cursor-pointer"
                  >
                    Kaizen Blueprint
                  </button>
                </div>
              </div>

              {/* Graphical Process Block Diagram */}
              <div className="bg-gray-900/60 border border-gray-800 p-6 sm:p-8 rounded-2xl relative">
                <div className="text-xs font-mono font-bold text-gray-400 uppercase tracking-widest border-b border-gray-800 pb-3 mb-5 flex justify-between items-center">
                  <span>📊 Core Six Sigma DMAIC Framework Flow</span>
                  <span className="text-amber-400">Active Stage</span>
                </div>

                <div className="space-y-3 font-mono">
                  <div className="flex items-center gap-3 p-3 bg-gray-900 border-l-4 border-amber-500 rounded">
                    <span className="p-1 px-2 bg-gray-800 rounded font-bold text-xs">D</span>
                    <div className="text-xs">
                      <div className="font-bold text-white">Define (Business Goals)</div>
                      <div className="text-gray-400 text-[10px]">Identify CTQ parameters and project charter structures</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-gray-900 border-l-4 border-amber-400 rounded">
                    <span className="p-1 px-2 bg-gray-800 rounded font-bold text-xs">M</span>
                    <div className="text-xs">
                      <div className="font-bold text-white">Measure (Reliability Analysis)</div>
                      <div className="text-gray-400 text-[10px]">Calculate baseline cycle margins & Gauge R&R data</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-gray-900 border-l-4 border-yellow-300 rounded">
                    <span className="p-1 px-2 bg-gray-800 rounded font-bold text-xs">A</span>
                    <div className="text-xs">
                      <div className="font-bold text-white">Analyze (Root-Cause Engine)</div>
                      <div className="text-gray-400 text-[10px]">Hypothesis testing, FMEA tables, Fishbone diagnostics</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-gray-900 border-l-4 border-emerald-500 rounded opacity-60">
                    <span className="p-1 px-2 bg-gray-800 rounded font-bold text-xs">I</span>
                    <div className="text-xs">
                      <div className="font-bold text-white">Improve (Automation Matrix)</div>
                      <div className="text-gray-400 text-[10px]">Execute Lean pilots & robotic conveyor setups</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 p-3 bg-gray-900 border-l-4 border-blue-500 rounded opacity-60">
                    <span className="p-1 px-2 bg-gray-800 rounded font-bold text-xs">C</span>
                    <div className="text-xs">
                      <div className="font-bold text-white">Control (Standardization Run)</div>
                      <div className="text-gray-400 text-[10px]">SOP designs, control sheets, Poka-Yoke checkpoints</div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 5. Metrics Section (Outcome & Placements) */}
      <section className="py-20 bg-gray-950/40 border-t border-gray-900" id="placement-outcomes-live">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            <div className="lg:col-span-1">
              <span className="text-xs font-mono font-bold text-emerald-400 uppercase tracking-widest">Alumni Impact</span>
              <h2 className="text-3xl font-sans font-bold text-white tracking-tight mt-2">
                Placement Support & Real Earnings
              </h2>
              <p className="text-gray-400 mt-4 text-xs leading-relaxed">
                Our active hiring network connects certified PG engineers directly with core companies. We provide dedicated personal coordinators who handle resume tailoring and host detailed mock sessions.
              </p>

              <div className="mt-8 p-6 bg-gray-900 border border-gray-800 rounded-2xl">
                <div className="font-semibold text-xs text-gray-400 uppercase font-mono mb-4">Salary Levels Assured</div>
                <div className="space-y-4">
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-gray-400">🎓 Freshers starting salary:</span>
                    <strong className="text-white">₹3.5LPA - ₹8LPA</strong>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-gray-400">💼 Experienced engineers:</span>
                    <strong className="text-white">40% - 60% Avg Hike</strong>
                  </div>
                  <div className="flex justify-between items-center text-xs">
                    <span className="text-gray-400">🧑‍💼 Lead / Managers:</span>
                    <strong className="text-white">₹12LPA - ₹25LPA</strong>
                  </div>
                </div>
              </div>

              <div className="mt-6">
                <button 
                  onClick={() => setView({ type: 'placement' })}
                  className="inline-flex items-center gap-2 text-amber-400 font-bold font-mono text-xs hover:underline cursor-pointer"
                >
                  Explore Real Placements Directory <ArrowRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Metrics Graphs */}
            <div className="lg:col-span-2 grid grid-cols-1 md:grid-cols-2 gap-6">
              {PLACEMENT_STATS.map((stat) => (
                <div key={stat.branch} className="bg-gray-900 p-6 border border-gray-800 rounded-2xl flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-center mb-4">
                      <span className="font-bold text-white text-base font-sans">{stat.branch} Specialization</span>
                      <span className="text-xs bg-emerald-500/10 text-emerald-400 font-mono px-2 py-0.5 rounded-full font-bold">
                        {stat.placementRate}% Placed
                      </span>
                    </div>

                    <div className="grid grid-cols-2 gap-4 border-y border-gray-800 py-3 mb-4 text-xs font-mono">
                      <div>
                        <div className="text-gray-500">Highest Salary</div>
                        <div className="font-bold text-amber-400 text-sm mt-0.5">{stat.highestPackage}</div>
                      </div>
                      <div>
                        <div className="text-gray-500">Average Class CTC</div>
                        <div className="font-bold text-white text-sm mt-0.5">{stat.averagePackage}</div>
                      </div>
                    </div>
                  </div>

                  {/* SVG Bar Visualisation */}
                  <div>
                    <div className="flex justify-between text-[11px] text-gray-500 mb-1 font-mono">
                      <span>Course placement benchmark</span>
                      <span>Target: 80%</span>
                    </div>
                    <div className="w-full bg-gray-800 rounded-full h-2">
                      <div 
                        className="bg-gradient-to-r from-amber-400 to-amber-500 h-2 rounded-full" 
                        style={{ width: `${stat.placementRate}%` }}
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* 6. Testimonials Spotlight */}
      <section className="py-20 border-t border-gray-900" id="testimonials-spotlight">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <span className="text-xs font-mono font-bold text-amber-400 uppercase tracking-widest bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
              Validated Success Stories
            </span>
            <h2 className="text-3xl font-sans font-bold text-white tracking-tight mt-4">
              Feedback From Certified Engineers
            </h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {TESTIMONIALS.map((t, idx) => (
              <div key={idx} className="bg-gray-900 border border-gray-800 p-6 rounded-2xl flex flex-col justify-between shadow-xl">
                <div>
                  <div className="flex gap-1 text-amber-400 mb-4">
                    <Star className="h-4 w-4 fill-amber-400" />
                    <Star className="h-4 w-4 fill-amber-400" />
                    <Star className="h-4 w-4 fill-amber-400" />
                    <Star className="h-4 w-4 fill-amber-400" />
                    <Star className="h-4 w-4 fill-amber-400" />
                  </div>
                  <p className="text-xs text-gray-300 italic leading-relaxed">
                    "{t.text}"
                  </p>
                </div>

                <div className="mt-6 pt-5 border-t border-gray-800 flex items-center gap-3">
                  <img 
                    src={t.avatar} 
                    alt={t.name} 
                    className="h-10 w-10 rounded-full object-cover ring-2 ring-amber-400/30" 
                    referrerPolicy="no-referrer"
                  />
                  <div>
                    <h4 className="font-bold text-white text-xs">{t.name}</h4>
                    <span className="text-[10px] text-gray-400 font-mono block">{t.role} @ {t.company}</span>
                    <span className="text-[10px] bg-emerald-500/10 text-emerald-450 font-bold block mt-1 font-mono px-1.5 py-0.5 rounded w-fit">
                      {t.outcome}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. Hiring Partners Showcase */}
      <section className="py-16 bg-gray-950/80 border-t border-gray-900" id="hiring-partners-showcase">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-xs font-semibold uppercase font-mono tracking-widest text-amber-400 mb-8">
            200+ COMPREHENSIVE RECRUITER PARTNERS IN ALL BRANCHES
          </p>
          <div className="flex flex-wrap justify-center items-center gap-8 sm:gap-12 opacity-60 grayscale hover:grayscale-0 transition-all duration-500">
            {RECRUITERS.map((rec, idx) => (
              <span key={idx} className="font-sans font-extrabold text-gray-500 text-lg hover:text-white transition-colors tracking-tight font-mono">
                {rec.logo}
              </span>
            ))}
          </div>
        </div>
      </section>

      {/* 8. Global Bottom CTA */}
      <section className="py-20 bg-gradient-to-b from-[#0A0D17] to-[#04060A]" id="bottom-cta-banner">
        <div className="max-w-5xl mx-auto px-4 text-center">
          <Award className="h-12 w-12 text-amber-400 mx-auto stroke-[1.5] mb-6 animate-pulse" />
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
            Ready to Accelerate Your Career Path?
          </h2>
          <p className="text-gray-400 mt-4 text-sm max-w-xl mx-auto leading-relaxed">
            Get personalized consultation from Sixsigma AI advisors today. Discuss customizable EMI structures and complete your blockchain program profile.
          </p>

          <div className="mt-8 flex flex-col sm:flex-row gap-4 justify-center">
            <button 
              onClick={() => handleAudienceClick('fresher')}
              className="px-8 py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-black rounded-lg text-sm tracking-wide uppercase transition-all shadow-xl shadow-amber-500/10 cursor-pointer"
            >
              🎓 I am a Fresher Track
            </button>
            <button 
              onClick={() => handleAudienceClick('experienced')}
              className="px-8 py-3 bg-gray-900 hover:bg-gray-800 text-white font-black rounded-lg text-sm tracking-wide uppercase transition-all border border-gray-800 cursor-pointer"
            >
              💼 I am Experienced Track
            </button>
          </div>
          
          <p className="text-gray-500 text-[10px] mt-4 font-mono">
            Registration instantly generates your standard 90-Day Free Pilot trial account.
          </p>
        </div>
      </section>

    </div>
  );
}
