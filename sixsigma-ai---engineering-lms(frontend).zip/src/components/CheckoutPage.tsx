import React, { useState } from 'react';
import { ViewState } from '../types';
import { 
  ArrowLeft, 
  CreditCard, 
  ShieldCheck, 
  CheckCircle, 
  HelpCircle, 
  Sparkles, 
  ArrowRight,
  BookmarkCheck,
  AlertCircle
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface CheckoutPageProps {
  plan: {
    name: string;
    price: number;
    type: string;
    branchId?: string;
  };
  setView: (view: ViewState) => void;
  onPaymentSuccess: () => void;
}

export default function CheckoutPage({ plan, setView, onPaymentSuccess }: CheckoutPageProps) {
  // Input fields
  const [cardNumber, setCardNumber] = useState('');
  const [cardName, setCardName] = useState('');
  const [cardExpiry, setCardExpiry] = useState('');
  const [cardCvc, setCardCvc] = useState('');
  const [selectedEmiTerm, setSelectedEmiTerm] = useState('3-mo');

  // Interactive flow states
  const [errorText, setErrorText] = useState('');
  const [isProcessing, setIsProcessing] = useState(false);
  const [stepSuccess, setStepSuccess] = useState(false);

  // Dynamic formatting functions
  const handleCardNumberKey = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 16) value = value.substring(0, 16);
    // Add space separations
    const parts = [];
    for (let i = 0; i < value.length; i += 4) {
      parts.push(value.substring(i, i + 4));
    }
    setCardNumber(parts.join(' '));
  };

  const handleExpiryKey = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length > 4) value = value.substring(0, 4);
    if (value.length > 2) {
      setCardExpiry(`${value.substring(0, 2)}/${value.substring(2)}`);
    } else {
      setCardExpiry(value);
    }
  };

  const handleCvcKey = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value.replace(/\D/g, '');
    if (value.length <= 3) {
      setCardCvc(value);
    }
  };

  const executeMockPayment = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText('');

    // Perform interactive validations
    if (!cardNumber || cardNumber.replace(/\s/g, '').length !== 16) {
      setErrorText('Please specify a valid 16-digit credit or debit card.');
      return;
    }

    if (!cardName) {
      setErrorText('Cardholder full name is required.');
      return;
    }

    if (!cardExpiry || !cardExpiry.includes('/')) {
      setErrorText('Card expiration MM/YY parameter is crucial.');
      return;
    }

    if (!cardCvc || cardCvc.length !== 3) {
      setErrorText('CVC 3-digit verification code is required.');
      return;
    }

    // Trigger mock process state
    setIsProcessing(true);

    setTimeout(() => {
      setIsProcessing(false);
      setStepSuccess(true);
    }, 2200);
  };

  const handleCompleteRedirect = () => {
    onPaymentSuccess();
    setView({ type: 'dashboard' });
  };

  const emiOptions = [
    { id: '3-mo', term: '3 Months term', emiVal: Math.round(plan.price / 3) },
    { id: '6-mo', term: '6 Months term', emiVal: Math.round(plan.price / 6) },
    { id: '12-mo', term: '12 Months zero-interest', emiVal: Math.round(plan.price / 12) }
  ];

  const activeEmiValue = emiOptions.find(o => o.id === selectedEmiTerm)?.emiVal || plan.price;

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 py-12" id="checkout-page-root">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        
        {/* Back navigation */}
        <button 
          onClick={() => setView({ type: 'home' })}
          className="inline-flex items-center space-x-2 text-xs text-gray-400 hover:text-amber-400 font-mono transition-colors mb-8 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Return to Homepage Portal</span>
        </button>

        <h1 className="text-3xl font-sans font-extrabold text-white tracking-tight mb-8">
          Secure Application Checkout
        </h1>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
          
          {/* Left Column: Order details & EMI choices */}
          <div className="space-y-6">
            
            {/* Plan item summary card */}
            <div className="bg-gray-900 border border-gray-850 p-6 rounded-2xl">
              <span className="text-[10px] font-mono text-amber-400 font-bold tracking-widest uppercase">COURSE ENROLLMENT SUMMARIZER</span>
              <h3 className="text-lg font-bold text-white mt-1">{plan.name}</h3>
              <p className="text-xs text-gray-400 mt-1">Includes 12 months full-stack LMS access, active blockchain accredited credentials, and direct placement manager assistance.</p>
              
              <div className="border-t border-gray-800 mt-5 pt-5 flex justify-between items-center">
                <span className="text-sm text-gray-400">Core Tuitions Price:</span>
                <strong className="text-2xl font-extrabold text-white">₹{plan.price.toLocaleString('en-IN')}</strong>
              </div>
            </div>

            {/* Easy EMI calculator lists */}
            <div className="bg-gray-900 border border-gray-850 p-6 rounded-2xl">
              <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-4">
                Select Installment Schedule (0% Interest)
              </h4>

              <div className="space-y-3">
                {emiOptions.map(option => (
                  <label 
                    key={option.id}
                    className={`p-4 rounded-xl border flex justify-between items-center cursor-pointer transition-all ${
                      selectedEmiTerm === option.id 
                        ? 'bg-amber-400/5 border-amber-400 text-white font-black' 
                        : 'bg-gray-950/40 border-gray-850 text-gray-300 hover:bg-gray-900'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <input 
                        type="radio"
                        name="emi"
                        value={option.id}
                        checked={selectedEmiTerm === option.id}
                        onChange={() => setSelectedEmiTerm(option.id)}
                        className="accent-amber-400 h-4 w-4 cursor-pointer"
                      />
                      <span className="text-xs">{option.term}</span>
                    </div>
                    <strong className="text-sm font-mono font-extrabold">₹{option.emiVal.toLocaleString('en-IN')}/mo</strong>
                  </label>
                ))}
              </div>
            </div>

          </div>

          {/* Right Column: Credit Card Visualizer + Form Input field */}
          <div className="bg-gray-900 border border-gray-850 p-6 sm:p-8 rounded-2xl space-y-6 relative overflow-hidden">
            <div className="absolute right-0 top-0 h-32 w-32 bg-amber-500/5 rounded-full blur-3xl" />
            
            <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-2">
              Credit / Debit Card Transaction Details
            </h4>

            {/* Credit Card Graphic Simulator card */}
            <div className="bg-gradient-to-tr from-amber-400 to-yellow-600 p-5 rounded-2xl text-gray-950 shadow-xl relative aspect-[1.58/1] overflow-hidden flex flex-col justify-between max-w-sm mx-auto">
              <div className="flex justify-between items-start">
                <span className="text-[10px] font-mono tracking-widest leading-none font-bold">SIXSIGMA AI CREDENTIALS</span>
                {/* Visual Chip card icon */}
                <div className="h-7 w-9 bg-gradient-to-br from-amber-200 to-yellow-100 rounded-md border border-gray-950/20 shadow" />
              </div>

              <div>
                {/* Formatted number */}
                <div className="font-mono text-base tracking-widest text-shadow-sm font-black text-center">
                  {cardNumber || '•••• •••• •••• ••••'}
                </div>
              </div>

              <div className="flex justify-between text-xs font-mono">
                <div>
                  <div className="text-[9px] uppercase opacity-70">Cardholder</div>
                  <div className="font-extrabold truncate max-w-[150px]">{cardName.toUpperCase() || 'RAMESH KUMAR'}</div>
                </div>

                <div className="text-right">
                  <div className="text-[9px] uppercase opacity-70">Expiry</div>
                  <div className="font-extrabold">{cardExpiry || 'MM/YY'}</div>
                </div>
              </div>
            </div>

            {/* Standard payment fields input */}
            <form onSubmit={executeMockPayment} className="space-y-4">
              <div>
                <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Cardholder Name</label>
                <input 
                  type="text"
                  required
                  value={cardName}
                  onChange={(e) => setCardName(e.target.value)}
                  placeholder="e.g. Ramesh Kumar"
                  className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl px-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white font-sans"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">16-Digit Card Number</label>
                <div className="relative">
                  <input 
                    type="text"
                    required
                    value={cardNumber}
                    onChange={handleCardNumberKey}
                    placeholder="4321 0000 1111 2222"
                    className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl px-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white font-mono"
                  />
                  <CreditCard className="absolute right-3 top-3.5 h-4 w-4 text-gray-500" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5 font-mono">Expiration (MM/YY)</label>
                  <input 
                    type="text"
                    required
                    value={cardExpiry}
                    onChange={handleExpiryKey}
                    placeholder="12/28"
                    className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl px-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white font-mono"
                  />
                </div>

                <div>
                  <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5 font-mono">CVC Code (3-Digits)</label>
                  <input 
                    type="password"
                    required
                    maxLength={3}
                    value={cardCvc}
                    onChange={handleCvcKey}
                    placeholder="•••"
                    className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl px-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white font-mono"
                  />
                </div>
              </div>

              {/* Checks */}
              {errorText && (
                <div className="p-3 bg-red-950/20 border border-red-900/50 text-red-400 text-xs rounded-xl flex gap-1.5 items-center font-mono">
                  <AlertCircle className="h-4 w-4" />
                  <span>{errorText}</span>
                </div>
              )}

              {/* Action buttons */}
              <button 
                type="submit"
                disabled={isProcessing}
                className="w-full text-center py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 disabled:opacity-40 font-black rounded-xl text-xs uppercase tracking-wide cursor-pointer transition-all shadow-md shadow-amber-500/5"
              >
                {isProcessing ? 'Validating Bank Authorization...' : `Pay Installment - First Month ₹${activeEmiValue.toLocaleString('en-IN')}`}
              </button>

            </form>

            <div className="text-[10px] font-mono text-gray-500 text-center flex items-center justify-center gap-1.5 mt-4">
              <ShieldCheck className="h-4 w-4 text-emerald-400" />
              <span>SSL SECURE ENCRYPTED GATEWAY DIRECT CHANNELS</span>
            </div>

          </div>

        </div>

      </div>

      {/* Success state overlay dialog */}
      <AnimatePresence>
        {stepSuccess && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4 backdrop-blur-sm"
          >
            <motion.div 
              initial={{ scale: 0.95 }}
              animate={{ scale: 1 }}
              exit={{ scale: 0.95 }}
              className="bg-gray-900 border border-gray-800 p-8 rounded-3xl max-w-sm w-full text-center space-y-6 shadow-2xl"
            >
              <div className="p-4 bg-emerald-500/10 text-emerald-400 w-fit rounded-full mx-auto border border-emerald-500/20">
                <BookmarkCheck className="h-10 w-10 animate-bounce" />
              </div>

              <div>
                <h3 className="text-xl font-sans font-extrabold text-white">Application Activated!</h3>
                <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                  First monthly installment of ₹{activeEmiValue.toLocaleString('en-IN')} has been cleared. Premium course locks are now fully active on your student workspace profile.
                </p>
              </div>

              <button 
                onClick={handleCompleteRedirect}
                className="w-full text-center py-3 bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-500 hover:to-emerald-600 text-gray-950 font-black rounded-xl text-xs uppercase tracking-wide cursor-pointer shadow-lg"
              >
                Enter Learner Workspace
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

    </div>
  );
}
