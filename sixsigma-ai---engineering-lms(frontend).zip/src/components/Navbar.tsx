import { useState } from 'react';
import { UserSession, ViewState, UserRole } from '../types';
import { 
  GraduationCap, 
  Menu, 
  X, 
  ChevronDown, 
  LogOut, 
  User, 
  Briefcase, 
  TrendingUp, 
  Layers,
  BookOpen,
  Award,
  ShieldCheck,
  Building2,
  Sparkles
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BRANCHES_DATA } from '../data/courses';

interface NavbarProps {
  session: UserSession;
  setSession: (session: UserSession) => void;
  view: ViewState;
  setView: (view: ViewState) => void;
}

export default function Navbar({ session, setSession, view, setView }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<'programs' | 'process' | 'dev' | null>(null);

  const handleLogout = () => {
    setSession({ isLoggedIn: false, user: null });
    setView({ type: 'home' });
    setIsOpen(false);
  };

  const handleAudienceClick = (audience: UserRole) => {
    setView({ type: 'programmes', audience });
    setActiveDropdown(null);
    setIsOpen(false);
  };

  const handleBranchClick = (branchId: string) => {
    setView({ type: 'branch', branchId });
    setActiveDropdown(null);
    setIsOpen(false);
  };

  const handleProcessExcellenceClick = (progId: 'six-sigma' | 'kaizen' | '5s') => {
    setView({ type: 'process-excellence', progId });
    setActiveDropdown(null);
    setIsOpen(false);
  };

  const setFastUserRoleState = (role: UserRole, isPremium: boolean) => {
    setSession({
      isLoggedIn: true,
      user: {
        name: role === 'fresher' ? 'Ramesh Kumar' : role === 'experienced' ? 'Nikita Deshmukh' : 'Sanjay Abraham',
        email: role === 'fresher' ? 'fresher@sixsigma.ai' : role === 'experienced' ? 'experienced@sixsigma.ai' : 'manager@sixsigma.ai',
        role,
        branch: role === 'fresher' ? 'electrical' : role === 'experienced' ? 'mechanical' : 'computer',
        isPremium
      }
    });
    setView({ type: 'dashboard' });
    setActiveDropdown(null);
    setIsOpen(false);
  };

  const getActiveTabClass = (type: string) => {
    if (view.type === type) {
      return "text-amber-400 font-medium border-b-2 border-amber-400 pb-1";
    }
    return "text-gray-300 hover:text-amber-400 transition-colors";
  };

  return (
    <nav className="sticky top-0 z-50 bg-[#0B0F19] text-white border-b border-gray-800 shadow-xl" id="nav-element">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          
          {/* Logo */}
          <div className="flex items-center space-x-3 cursor-pointer" onClick={() => setView({ type: 'home' })} id="logo-container">
            <div className="p-2.5 bg-gradient-to-br from-amber-400 to-amber-600 rounded-xl shadow-lg ring-1 ring-amber-300/30">
              <GraduationCap className="h-7 w-7 text-gray-900 stroke-[2.5]" />
            </div>
            <div>
              <span className="font-sans font-bold text-xl tracking-tight bg-gradient-to-r from-amber-300 via-amber-400 to-amber-100 bg-clip-text text-transparent">
                SIXSIGMA AI
              </span>
              <p className="font-mono text-[9px] text-gray-400 tracking-widest leading-none mt-0.5 uppercase">
                Process Excellence LMS
              </p>
            </div>
          </div>

          {/* Desktop Right Side Nav */}
          <div className="hidden lg:flex items-center space-x-7 text-sm font-medium">
            
            {/* PG Program Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setActiveDropdown('programs')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="flex items-center space-x-1.5 py-2 text-gray-300 hover:text-amber-400 transition-colors focus:outline-none">
                <span>PG Programmes</span>
                <ChevronDown className="h-4 w-4" />
              </button>

              <AnimatePresence>
                {activeDropdown === 'programs' && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute left-1/2 -translate-x-1/2 mt-0 w-[580px] bg-gray-950 border border-gray-800 rounded-2xl shadow-2xl p-6 grid grid-cols-2 gap-6 ring-1 ring-black/50"
                  >
                    <div>
                      <h4 className="font-semibold text-xs text-amber-400 tracking-wider uppercase mb-3 flex items-center gap-1.5">
                        <User className="h-3.5 w-3.5" /> By Target Audience
                      </h4>
                      <div className="space-y-1">
                        <button onClick={() => handleAudienceClick('fresher')} className="w-full text-left p-2.5 hover:bg-gray-900 rounded-lg transition-all group">
                          <div className="font-medium text-gray-200 group-hover:text-amber-300 text-sm">🎓 Freshers Track</div>
                          <div className="text-xs text-gray-400 font-normal">Degree + Placement Guarantee (0-2 Yrs)</div>
                        </button>
                        <button onClick={() => handleAudienceClick('experienced')} className="w-full text-left p-2.5 hover:bg-gray-900 rounded-lg transition-all group">
                          <div className="font-medium text-gray-200 group-hover:text-amber-300 text-sm">💼 Experienced Track</div>
                          <div className="text-xs text-gray-400 font-normal">Weekend batches & career promotion (2-10 Yrs)</div>
                        </button>
                        <button onClick={() => handleAudienceClick('manager')} className="w-full text-left p-2.5 hover:bg-gray-900 rounded-lg transition-all group">
                          <div className="font-medium text-gray-200 group-hover:text-amber-300 text-sm">🧑‍💼 Managers Track</div>
                          <div className="text-xs text-gray-400 font-normal">Industrial 4.0, Strategy & NetZero (10+ Yrs)</div>
                        </button>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-semibold text-xs text-amber-400 tracking-wider uppercase mb-3 flex items-center gap-1.5">
                        <Layers className="h-3.5 w-3.5" /> By Engineering Branch
                      </h4>
                      <div className="grid grid-cols-2 gap-1.5 text-xs">
                        {BRANCHES_DATA.map(b => (
                          <button 
                            key={b.id} 
                            onClick={() => handleBranchClick(b.id)}
                            className="text-left font-medium p-2 hover:bg-gray-900 rounded-md text-gray-300 hover:text-amber-300 transition-colors"
                          >
                            • {b.name.split(' ')[0]}
                          </button>
                        ))}
                      </div>

                      <div className="mt-5 pt-4 border-t border-gray-800">
                        <h4 className="font-semibold text-xs text-amber-400 tracking-wider uppercase mb-2 flex items-center gap-1.5">
                          <BookOpen className="h-3.5 w-3.5" /> By Programme Length
                        </h4>
                        <div className="flex gap-4 text-xs text-gray-300">
                          <button onClick={() => handleAudienceClick('fresher')} className="hover:text-amber-400">✔ Certificate (6M)</button>
                          <button onClick={() => handleAudienceClick('manager')} className="hover:text-amber-400">✔ Adv Diploma (1Yr)</button>
                        </div>
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Process Excellence Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setActiveDropdown('process')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="flex items-center space-x-1.5 py-2 text-gray-300 hover:text-amber-400 transition-colors focus:outline-none">
                <span>Process Excellence</span>
                <ChevronDown className="h-4 w-4" />
              </button>

              <AnimatePresence>
                {activeDropdown === 'process' && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute left-0 mt-0 w-64 bg-gray-950 border border-gray-800 rounded-xl shadow-2xl p-4 space-y-1"
                  >
                    <button 
                      onClick={() => handleProcessExcellenceClick('six-sigma')} 
                      className="w-full text-left p-2 hover:bg-gray-900 rounded-lg transition-colors flex items-center space-x-3 group"
                    >
                      <span className="text-amber-400">📊</span>
                      <div>
                        <div className="font-medium text-gray-200 group-hover:text-amber-300 text-sm">Six Sigma Belts</div>
                        <p className="text-[10px] text-gray-500">White to Black Belt level courses</p>
                      </div>
                    </button>
                    <button 
                      onClick={() => handleProcessExcellenceClick('kaizen')} 
                      className="w-full text-left p-2 hover:bg-gray-900 rounded-lg transition-colors flex items-center space-x-3 group"
                    >
                      <span className="text-amber-400">🔄</span>
                      <div>
                        <div className="font-medium text-gray-200 group-hover:text-amber-300 text-sm">Kaizen Blueprint</div>
                        <p className="text-[10px] text-gray-500">Continuous speed operations</p>
                      </div>
                    </button>
                    <button 
                      onClick={() => handleProcessExcellenceClick('5s')} 
                      className="w-full text-left p-2 hover:bg-gray-900 rounded-lg transition-colors flex items-center space-x-3 group"
                    >
                      <span className="text-amber-400">🏭</span>
                      <div>
                        <div className="font-medium text-gray-200 group-hover:text-amber-300 text-sm">5S Workplace Org</div>
                        <p className="text-[10px] text-gray-500">Optimize shopfloor space</p>
                      </div>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {/* Placements */}
            <button 
              onClick={() => setView({ type: 'placement' })}
              className={getActiveTabClass('placement')}
            >
              Placements
            </button>

            {/* Corporate Upskilling */}
            <button 
              onClick={() => setView({ type: 'corporate' })}
              className={getActiveTabClass('corporate')}
            >
              Corporate Training
            </button>

            <button 
              onClick={() => setView({ type: 'insights' })} 
              className={getActiveTabClass('insights')}
            >
              Insights
            </button>
            
          </div>

          {/* Quick Dev Switch / Demo Controls & Credentials */}
          <div className="hidden lg:flex items-center space-x-4">
            
            {/* Quick Demo Switcher Dropdown */}
            <div 
              className="relative"
              onMouseEnter={() => setActiveDropdown('dev')}
              onMouseLeave={() => setActiveDropdown(null)}
            >
              <button className="flex items-center space-x-1.5 px-3 py-1.5 bg-gray-900 hover:bg-amber-500/10 border border-gray-800 hover:border-amber-500/50 rounded-lg text-xs font-mono text-amber-400 cursor-pointer">
                <Sparkles className="h-3 w-3 animate-pulse" />
                <span>Quick Role Demo</span>
                <ChevronDown className="h-3 w-3" />
              </button>

              <AnimatePresence>
                {activeDropdown === 'dev' && (
                  <motion.div 
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="absolute right-0 mt-1 w-64 bg-gray-950 border border-gray-800 rounded-xl shadow-2xl p-4 space-y-2 text-xs"
                  >
                    <div className="font-semibold text-gray-400 uppercase tracking-widest text-[9px] mb-1">Simulate LMS Profiles</div>
                    <button 
                      onClick={() => setFastUserRoleState('fresher', false)}
                      className="w-full text-left p-2 hover:bg-gray-900 rounded-md flex justify-between items-center group text-gray-300 hover:text-white"
                    >
                      <span>🎓 Ramesh (Fresher - Free)</span>
                      <span className="text-[9px] bg-blue-900/40 text-blue-300 px-1.5 py-0.5 rounded">Core</span>
                    </button>
                    <button 
                      onClick={() => setFastUserRoleState('experienced', true)}
                      className="w-full text-left p-2 hover:bg-gray-900 rounded-md flex justify-between items-center group text-gray-300 hover:text-white"
                    >
                      <span>💼 Nikita (Experienced - Pro)</span>
                      <span className="text-[9px] bg-amber-500/20 text-cream px-1.5 py-0.5 rounded text-amber-300 font-semibold">Premium</span>
                    </button>
                    <button 
                      onClick={() => setFastUserRoleState('manager', true)}
                      className="w-full text-left p-2 hover:bg-gray-900 rounded-md flex justify-between items-center group text-gray-300 hover:text-white"
                    >
                      <span>🧑‍💼 Sanjay (Manager - Pro)</span>
                      <span className="text-[9px] bg-emerald-500/20 text-cream px-1.5 py-0.5 rounded text-emerald-300 font-semibold">Pro Partner</span>
                    </button>

                    <div className="border-t border-gray-800 my-2 pt-2 text-[10px] text-gray-500">
                      Instantly unlocks Student Workspace and video curriculum player tools.
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>

            {session.isLoggedIn ? (
              <div className="flex items-center space-x-3 pl-3 border-l border-gray-800">
                <button 
                  onClick={() => setView({ type: 'dashboard' })}
                  className="flex items-center space-x-2 px-3 py-2 bg-gradient-to-r from-amber-400 to-amber-600 hover:from-amber-500 hover:to-amber-700 text-gray-950 font-semibold rounded-lg text-xs shadow-md shadow-amber-500/10 cursor-pointer"
                >
                  <Briefcase className="h-3.5 w-3.5" />
                  <span>Learner Workspace</span>
                </button>
                <button 
                  onClick={handleLogout}
                  title="Sign Out"
                  className="p-2 border border-gray-800 hover:border-red-500/50 text-gray-400 hover:text-red-400 rounded-lg transition-colors cursor-pointer"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              </div>
            ) : (
              <div className="flex items-center space-x-3 pl-2">
                <button 
                  onClick={() => setView({ type: 'auth', isSignUp: false })}
                  className="text-gray-300 hover:text-white text-sm transition-colors cursor-pointer"
                >
                  Sign In
                </button>
                <button 
                  onClick={() => setView({ type: 'auth', isSignUp: true })}
                  className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-bold rounded-lg transition-all shadow-md shadow-amber-500/5 hover:scale-[1.02] text-sm cursor-pointer"
                >
                  Register State
                </button>
              </div>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="lg:hidden flex items-center space-x-2">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-lg text-gray-400 hover:text-white hover:bg-gray-900 focus:outline-none"
            >
              {isOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isOpen && (
          <motion.div 
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-gray-955 border-b border-gray-800 overflow-hidden"
          >
            <div className="px-4 pt-2 pb-6 space-y-3">
              
              <div className="font-bold text-xs text-amber-400 tracking-wider uppercase border-b border-gray-800 pb-1 pt-2">Programmes by Audience</div>
              <div className="grid grid-cols-3 gap-2">
                <button onClick={() => handleAudienceClick('fresher')} className="p-2 bg-gray-900 hover:bg-gray-800 text-xs rounded text-center text-gray-200">Freshers</button>
                <button onClick={() => handleAudienceClick('experienced')} className="p-2 bg-gray-900 hover:bg-gray-800 text-xs rounded text-center text-gray-200">Experienced</button>
                <button onClick={() => handleAudienceClick('manager')} className="p-2 bg-gray-900 hover:bg-gray-800 text-xs rounded text-center text-gray-200">Managers</button>
              </div>

              <div className="font-bold text-xs text-amber-400 tracking-wider uppercase border-b border-gray-800 pb-1 pt-2">By engineering branch</div>
              <div className="grid grid-cols-2 gap-2">
                {BRANCHES_DATA.map(b => (
                  <button 
                    key={b.id} 
                    onClick={() => handleBranchClick(b.id)}
                    className="p-1.5 bg-gray-900 hover:bg-gray-800 text-[11px] rounded text-left text-gray-300"
                  >
                    • {b.name}
                  </button>
                ))}
              </div>

              <div className="font-bold text-xs text-amber-400 tracking-wider uppercase border-b border-gray-800 pb-1 pt-2">Process Excellence</div>
              <div className="grid grid-cols-3 gap-2">
                <button onClick={() => handleProcessExcellenceClick('six-sigma')} className="p-2 bg-gray-900 hover:bg-gray-800 text-xs rounded text-center">Six Sigma</button>
                <button onClick={() => handleProcessExcellenceClick('kaizen')} className="p-2 bg-gray-900 hover:bg-gray-800 text-xs rounded text-center">Kaizen</button>
                <button onClick={() => handleProcessExcellenceClick('5s')} className="p-2 bg-gray-900 hover:bg-gray-800 text-xs rounded text-center">5S</button>
              </div>

              <div className="pt-3 flex flex-col space-y-2">
                <button onClick={() => { setView({ type: 'placement' }); setIsOpen(false); }} className="w-full text-left p-2.5 text-gray-300 hover:bg-gray-900 rounded font-medium">Placements Tracker</button>
                <button onClick={() => { setView({ type: 'corporate' }); setIsOpen(false); }} className="w-full text-left p-2.5 text-gray-300 hover:bg-gray-900 rounded font-medium">Corporate Upskilling</button>
                <button onClick={() => { setView({ type: 'insights' }); setIsOpen(false); }} className="w-full text-left p-2.5 text-gray-300 hover:bg-gray-900 rounded font-medium">Insights & Webinars</button>
              </div>

              <div className="border-t border-gray-800 pt-4 flex flex-col gap-2">
                {session.isLoggedIn ? (
                  <>
                    <button 
                      onClick={() => { setView({ type: 'dashboard' }); setIsOpen(false); }}
                      className="w-full text-center p-2.5 bg-amber-400 text-gray-950 font-bold rounded-lg text-sm"
                    >
                      Go to Dashboard
                    </button>
                    <button 
                      onClick={handleLogout}
                      className="w-full text-center p-2.5 bg-gray-900 hover:bg-red-900/30 text-red-400 font-semibold rounded-lg text-sm transition-colors border border-gray-800"
                    >
                      Sign Out
                    </button>
                  </>
                ) : (
                  <>
                    <button 
                      onClick={() => { setView({ type: 'auth', isSignUp: false }); setIsOpen(false); }}
                      className="w-full text-center p-2.5 bg-gray-900 text-gray-300 font-semibold rounded-lg text-sm"
                    >
                      Sign In
                    </button>
                    <button 
                      onClick={() => { setView({ type: 'auth', isSignUp: true }); setIsOpen(false); }}
                      className="w-full text-center p-2.5 bg-amber-400 text-gray-950 font-bold rounded-lg text-sm"
                    >
                      Register Now
                    </button>
                  </>
                )}
              </div>

            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
}
