import React, { useState } from 'react';
import { ViewState } from '../types';
import { 
  Building2, 
  ArrowLeft, 
  CheckCircle2, 
  Tv, 
  FileText, 
  Users, 
  MapPin, 
  Award, 
  TrendingUp, 
  Sparkles,
  Inbox,
  BookmarkCheck,
  Download
} from 'lucide-react';
import { motion } from 'motion/react';

interface ComponentProps {
  setView: (view: ViewState) => void;
}

// 1. Corporate Training component
export function CorporateTraining({ setView }: ComponentProps) {
  const [proposalSent, setProposalSent] = useState(false);
  const [corpName, setCorpName] = useState('');
  const [corpEmail, setCorpEmail] = useState('');
  const [employeeCount, setEmployeeCount] = useState('50-200');

  const handleCorpForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (corpName && corpEmail) {
      setProposalSent(true);
      setCorpName('');
      setCorpEmail('');
      setTimeout(() => setProposalSent(false), 5000);
    }
  };

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 py-12" id="corporate-training-root">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        <button 
          onClick={() => setView({ type: 'home' })}
          className="inline-flex items-center space-x-2 text-xs text-gray-400 hover:text-amber-400 font-mono transition-colors mb-8 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Landing dashboard</span>
        </button>

        <div className="text-center max-w-2xl mx-auto mb-12">
          <Building2 className="h-10 w-10 text-amber-400 mx-auto mb-4" />
          <h1 className="text-3xl font-sans font-extrabold text-white">Enterprise Scaled Upskilling</h1>
          <p className="text-xs text-gray-400 mt-2">
            Equip your engineering teams with six sigma black belt systems, MATLAB smart grids and digital twin modeling frameworks on white-labeled LMS platforms.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-10 items-start">
          
          <div className="space-y-6">
            <h3 className="text-base font-bold text-white uppercase font-mono tracking-wider">Enterprise Framework Benefits</h3>
            
            <div className="space-y-4">
              <div className="flex gap-3">
                <span className="p-1.5 bg-emerald-500/10 text-emerald-400 font-bold rounded-lg text-xs h-fit">✔</span>
                <div>
                  <h4 className="font-bold text-white text-sm">Custom Curricula tailored per branch</h4>
                  <p className="text-xs text-gray-450 mt-1">We alignment outline goals with departments (EV battery management, Revit BIM designing, or Kubernetes MLOps).</p>
                </div>
              </div>

              <div className="flex gap-3">
                <span className="p-1.5 bg-emerald-500/10 text-emerald-400 font-bold rounded-lg text-xs h-fit">✔</span>
                <div>
                  <h4 className="font-bold text-white text-sm">White-Labeled LMS Deployments</h4>
                  <p className="text-xs text-gray-450 mt-1">Host complete courses directly under your company brand, integrated with HR payroll metrics.</p>
                </div>
              </div>

              <div className="flex gap-3">
                <span className="p-1.5 bg-emerald-500/10 text-emerald-400 font-bold rounded-lg text-xs h-fit">✔</span>
                <div>
                  <h4 className="font-bold text-white text-sm">Real-time Employee L&D Analytics</h4>
                  <p className="text-xs text-gray-450 mt-1">Generate automated reporting dashboards showcasing progress indices, quiz records & active certifications.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Form Proposal submission */}
          <div className="bg-gray-900 border border-gray-850 p-6 rounded-2xl relative">
            <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-4">Request Custom Training Proposal</h4>

            <form onSubmit={handleCorpForm} className="space-y-4">
              <div>
                <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Company Name</label>
                <input 
                  type="text" 
                  required
                  value={corpName}
                  onChange={(e) => setCorpName(e.target.value)}
                  placeholder="e.g. Siemens Operating S.A."
                  className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl px-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Corporate Email</label>
                <input 
                  type="email" 
                  required
                  value={corpEmail}
                  onChange={(e) => setCorpEmail(e.target.value)}
                  placeholder="e.g. info@siemens.com"
                  className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl px-4 py-3 placeholder-gray-650 text-xs focus:outline-none text-white font-mono"
                />
              </div>

              <div>
                <label className="block text-[10px] uppercase font-mono font-bold text-gray-450 mb-1.5">Employee Size count</label>
                <select 
                  value={employeeCount}
                  onChange={(e) => setEmployeeCount(e.target.value)}
                  className="w-full bg-[#0E1321] border border-gray-800 focus:border-amber-400 rounded-xl p-3 text-xs focus:outline-none text-white"
                >
                  <option value="10-50">10-50 Engineers</option>
                  <option value="50-200">50-200 Engineers</option>
                  <option value="200+">200+ Corporate Division</option>
                </select>
              </div>

              <button 
                type="submit"
                className="w-full py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-black rounded-xl text-xs uppercase tracking-wide cursor-pointer shadow-md"
              >
                Send Proposal Request
              </button>
            </form>

            {proposalSent && (
              <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs rounded-xl font-mono text-center">
                ✔ Proposal registered! Corporate relations specialists will email templates inside of 12 hours.
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}

// 2. Insights & Resources component
export function InsightsPage({ setView }: ComponentProps) {
  const [subscribeyEnrolled, setSubscribeyEnrolled] = useState(false);
  const [subMail, setSubMail] = useState('');

  const webinars = [
    { title: 'Designing Smart Grid isolators via MATLAB Simulink', date: 'MAY 27, 2026', host: 'Satish Kumar (ABB lead)' },
    { title: 'Executing 5S Auditing systems across High-Density Warehouses', date: 'JUN 03, 2026', host: 'Nikita Deshmukh' }
  ];

  const handleSubscribeMail = (e: React.FormEvent) => {
    e.preventDefault();
    if (subMail) {
      setSubscribeyEnrolled(true);
      setSubMail('');
      setTimeout(() => setSubscribeyEnrolled(false), 4500);
    }
  };

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 py-12" id="insights-resource-root">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        <button 
          onClick={() => setView({ type: 'home' })}
          className="inline-flex items-center space-x-2 text-xs text-gray-400 hover:text-amber-400 font-mono transition-colors mb-8 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Landing dashboard</span>
        </button>

        <div className="text-center mb-12">
          <span className="font-mono text-xs uppercase text-amber-400 font-bold tracking-widest block mb-1">LEARNING TEMPLATES & BENCHMARKS</span>
          <h1 className="text-3xl font-sans font-extrabold text-white">Insights, Webinars & Resources</h1>
        </div>

        {/* Action content split */}
        <div className="space-y-8">
          
          {/* Live Webinars schedule list */}
          <div className="bg-gray-900 border border-gray-850 p-6 rounded-2xl">
            <h4 className="font-sans font-bold text-white text-sm uppercase tracking-wider mb-4 flex items-center gap-1.5 font-mono">
              <Tv className="h-4 w-4 text-amber-400" /> Free Live Interactive Webinars
            </h4>

            <div className="space-y-4">
              {webinars.map((webinar, idx) => (
                <div key={idx} className="p-4 bg-gray-950 border border-gray-800 rounded-xl flex items-center justify-between gap-4">
                  <div>
                    <h5 className="font-bold text-white text-xs">{webinar.title}</h5>
                    <span className="text-[10px] text-gray-400 font-mono block mt-1">Host: {webinar.host}</span>
                  </div>
                  <span className="text-[10px] font-mono text-amber-400 px-2 py-1 bg-amber-400/5 rounded shrink-0 font-bold border border-amber-400/10">
                    {webinar.date}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Downloadable templates tool block */}
          <div className="bg-gray-900 border border-gray-850 p-6 rounded-2xl">
            <h4 className="font-sans font-bold text-white text-sm uppercase tracking-wider mb-4 flex items-center gap-1.5 font-mono">
              <FileText className="h-4 w-4 text-emerald-400" /> Free PDF Resources & Excel Sheets
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="p-4 bg-black/40 border border-gray-800 rounded-xl flex justify-between items-center">
                <div>
                  <h5 className="font-bold text-white text-xs">ISO 50001 Energy Audit Checklist Template</h5>
                  <span className="text-[10px] text-gray-500 font-mono">Size: 1.2 MB</span>
                </div>
                <button onClick={() => alert('Checklist template downloaded!')} className="p-2 border border-gray-850 hover:border-emerald-500 rounded text-gray-400 hover:text-emerald-400 cursor-pointer">
                  <Download className="h-3.5 w-3.5" />
                </button>
              </div>

              <div className="p-4 bg-black/40 border border-gray-800 rounded-xl flex justify-between items-center">
                <div>
                  <h5 className="font-bold text-white text-xs">Lean Six Sigma DMAIC Templates Kit (.zip)</h5>
                  <span className="text-[10px] text-gray-500 font-mono">Size: 48.2 MB</span>
                </div>
                <button onClick={() => alert('DMAIC zip portfolio file downloaded!')} className="p-2 border border-gray-850 hover:border-emerald-500 rounded text-gray-400 hover:text-emerald-400 cursor-pointer">
                  <Download className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          </div>

          {/* Subscribe */}
          <div className="p-8 bg-gradient-to-br from-[#0F1626] to-[#0A0D15] border border-amber-500/25 rounded-2xl text-center">
            <h4 className="font-bold text-white text-sm">Subscribe to Sixsigma Weekly Newsletter</h4>
            <p className="text-[11px] text-gray-400 mt-1 max-w-md mx-auto">Get notified when new branch specific curricula or live hiring drives open up.</p>

            <form onSubmit={handleSubscribeMail} className="mt-4 flex gap-2 max-w-sm mx-auto">
              <input 
                type="email" 
                required
                value={subMail}
                onChange={(e) => setSubMail(e.target.value)}
                placeholder="Enter email..." 
                className="bg-gray-900 border border-gray-800 focus:border-amber-400 px-3 py-2 text-xs rounded-xl flex-grow font-mono text-white focus:outline-none"
              />
              <button type="submit" className="px-4 py-2 bg-amber-400 hover:bg-amber-500 text-gray-950 font-extrabold text-xs rounded-xl cursor-pointer">
                Subscribe
              </button>
            </form>

            {subscribeyEnrolled && (
              <div className="mt-3 text-emerald-400 text-[10px] font-mono">
                ✔ Subscribed! Verify your inbox for verification codes.
              </div>
            )}
          </div>

        </div>

      </div>
    </div>
  );
}

// 3. About page component
export function AboutPage({ setView }: ComponentProps) {
  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 py-12" id="about-us-page-root">
      <div className="max-w-4xl mx-auto px-4 sm:px-6">
        
        <button 
          onClick={() => setView({ type: 'home' })}
          className="inline-flex items-center space-x-2 text-xs text-gray-400 hover:text-amber-400 font-mono transition-colors mb-8 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Landing dashboard</span>
        </button>

        <div className="text-center mb-12">
          <Award className="h-10 w-10 text-amber-400 mx-auto mb-4" />
          <h1 className="text-3xl font-sans font-extrabold text-white">About Sixsigma AI</h1>
          <p className="text-xs text-gray-450 mt-1">Our mission is to establish gold-standard engineering education across the globe.</p>
        </div>

        <div className="space-y-8 text-sm text-gray-300 leading-relaxed font-sans">
          <p>
            Established in 2024, Sixsigma AI was designed to solve a fundamental disconnect in standard university academics: raw technical tools (AutoCAD, STAAD.Pro, Altium layouts, Minitab, MLOps, ETAP) are rarely taught with year-long corporate compliance parameters.
          </p>

          <p>
            We bridges this gap entirely by pairing rigorous 6 Months Certificate programs and 1 Year Advanced Diplomas with real on-site operational sandbox assignments. Each candidate profile stands fully checked and blockchain validated.
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 pt-6 border-t border-gray-850 text-center font-mono">
            <div>
              <div className="text-2xl font-extrabold text-white">5,000+</div>
              <div className="text-[10px] text-gray-500 uppercase mt-1">Engineers Graduated</div>
            </div>
            <div>
              <div className="text-2xl font-extrabold text-white">15+</div>
              <div className="text-[10px] text-gray-500 uppercase mt-1">Global Countries</div>
            </div>
            <div>
              <div className="text-2xl font-extrabold text-white">200+</div>
              <div className="text-[10px] text-gray-500 uppercase mt-1">Corporate Partners</div>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
