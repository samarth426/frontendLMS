import { UserSession, ViewState } from '../types';
import { 
  Award, 
  BookOpen, 
  Layers, 
  CheckCircle, 
  Clock, 
  Calendar, 
  ChevronRight, 
  Play, 
  TrendingUp, 
  MessageSquare, 
  Phone,
  BarChart,
  GitBranch,
  Inbox,
  AlertOctagon,
  HelpCircle,
  Video
} from 'lucide-react';
import { motion } from 'motion/react';
import { MOCK_COURSES } from '../data/courses';

interface StudentDashboardProps {
  session: UserSession;
  setView: (view: ViewState) => void;
  onOpenAITutor: () => void;
}

export default function StudentDashboard({ session, setView, onOpenAITutor }: StudentDashboardProps) {
  const { user } = session;

  if (!user) {
    return (
      <div className="bg-[#090D15] p-24 text-center text-white font-sans">
        <AlertOctagon className="h-12 w-12 text-red-400 mx-auto mb-4" />
        <h3 className="text-xl font-bold">Please log in to access the Dashboard Workspace</h3>
        <button 
          onClick={() => setView({ type: 'auth', isSignUp: false })}
          className="mt-6 px-6 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-bold rounded-xl text-xs uppercase"
        >
          Secure Sign In
        </button>
      </div>
    );
  }

  const handleStartCourse = (courseId: string) => {
    setView({
      type: 'player',
      courseId,
      lectureIndex: 0
    });
  };

  // Mock student stats
  const aggregateStats = {
    progressPercent: user.role === 'fresher' ? 45 : user.role === 'experienced' ? 70 : 85,
    completedLessons: user.role === 'fresher' ? 2 : user.role === 'experienced' ? 3 : 4,
    hoursInvested: user.role === 'fresher' ? 14 : user.role === 'experienced' ? 32 : 48,
    unlockedCertificates: user.role === 'fresher' ? 0 : 1
  };

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-150 py-12" id="student-dashboard-container">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Welcome Banner */}
        <div className="p-8 rounded-3xl bg-gradient-to-br from-gray-900 via-gray-950 to-gray-950 border border-gray-800 relative overflow-hidden mb-10">
          <div className="absolute right-0 top-0 h-32 w-32 bg-amber-500/5 rounded-full blur-2xl" />
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 relative z-10">
            <div>
              <span className="font-mono text-xs uppercase font-extrabold text-amber-400 tracking-wider">
                Active Engineering Session Group
              </span>
              <h1 className="text-2xl sm:text-4xl font-sans font-extrabold text-white mt-1 tracking-tight">
                Welcome back, {user.name}!
              </h1>
              <p className="text-xs text-gray-400 mt-1 font-mono">
                Member level: <span className="text-gray-350 font-bold">{user.role.toUpperCase()}</span> │ Selected Domain: <span className="text-gray-350 font-bold">{user.branch.toUpperCase()}</span>
              </p>
            </div>

            <div className="flex items-center gap-3">
              <button 
                onClick={onOpenAITutor}
                className="px-4 py-2 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-650 text-gray-950 font-black rounded-lg text-xs tracking-wide uppercase transition-all shadow-md shadow-amber-500/10 cursor-pointer flex items-center gap-1.5"
              >
                <MessageSquare className="h-4 w-4" />
                <span>Launch live AI tutor</span>
              </button>
            </div>
          </div>
        </div>

        {/* Dashboard Stat Counters Grid */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
          <div className="bg-gray-900 border border-gray-850 p-5 rounded-2xl">
            <span className="text-[10px] text-gray-500 uppercase font-mono font-bold block">overall progress percent</span>
            <div className="text-2xl font-extrabold text-white mt-1">{aggregateStats.progressPercent}%</div>
            
            <div className="w-full bg-gray-800 rounded-full h-1.5 mt-2.5">
              <div 
                className="bg-amber-400 h-1.5 rounded-full" 
                style={{ width: `${aggregateStats.progressPercent}%` }}
              />
            </div>
          </div>

          <div className="bg-gray-900 border border-gray-850 p-5 rounded-2xl">
            <span className="text-[10px] text-gray-500 uppercase font-mono font-bold block">active modules finished</span>
            <div className="text-2xl font-extrabold text-white mt-1">{aggregateStats.completedLessons} Completed</div>
            <p className="text-[10px] text-gray-400 mt-2 font-mono">Core certifications remaining: 1</p>
          </div>

          <div className="bg-gray-900 border border-gray-850 p-5 rounded-2xl">
            <span className="text-[10px] text-gray-500 uppercase font-mono font-bold block">hours invested</span>
            <div className="text-2xl font-extrabold text-white mt-1">{aggregateStats.hoursInvested} Hrs</div>
            <p className="text-[10px] text-gray-400 mt-2 font-mono">2.5 hours average daily time</p>
          </div>

          <div className="bg-gray-900 border border-gray-850 p-5 rounded-2xl">
            <span className="text-[10px] text-gray-500 uppercase font-mono font-bold block">unlocked certificates</span>
            <div className="text-2xl font-extrabold text-white mt-1 flex items-center gap-1.5">
              <span>{aggregateStats.unlockedCertificates} Verified</span>
              <Award className="h-5 w-5 text-amber-400 shrink-0" />
            </div>
            <p className="text-[10px] text-gray-400 mt-2 font-mono">Blockchain audit log ID: 10a8d</p>
          </div>
        </div>

        {/* Major Grid: Core syllabus on the Left, track resources & calendars on the Right */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: My Active Courses List */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex justify-between items-center mb-1">
              <h2 className="text-xl font-sans font-bold text-white flex items-center gap-2">
                <BookOpen className="h-5 w-5 text-amber-400" /> In-Progress Courses & Curricula
              </h2>
            </div>

            <div className="space-y-4">
              {MOCK_COURSES.map((course) => (
                <div 
                  key={course.id}
                  className="bg-gray-900 border border-gray-850 p-6 rounded-2xl flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6"
                >
                  <div className="space-y-1">
                    <span className="p-1 px-1.5 bg-gray-800 text-[10px] font-mono rounded text-amber-400 font-semibold uppercase">
                      {course.category} SPECIALIST
                    </span>
                    <h3 className="font-sans font-bold text-white text-base mt-2">{course.title}</h3>
                    <p className="text-xs text-gray-400 line-clamp-2 leading-relaxed">{course.description}</p>
                    
                    <div className="flex gap-4 text-[11px] text-gray-500 font-mono pt-2">
                      <span>🎬 {course.lessons.length} HD Lectures</span>
                      <span>⭐ {course.rating} Rating</span>
                    </div>
                  </div>

                  <button 
                    onClick={() => handleStartCourse(course.id)}
                    className="px-6 py-2.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-extrabold rounded-lg text-xs uppercase tracking-wide cursor-pointer shrink-0 shadow-md flex items-center gap-1"
                  >
                    <Play className="h-3 w-3 fill-gray-950" />
                    <span>Resume Course</span>
                  </button>
                </div>
              ))}
            </div>

            {/* Recommended Modules Section */}
            <div className="pt-4 border-t border-gray-850">
              <h3 className="text-lg font-sans font-bold text-white mb-4">Recommended Continuous Modules</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="p-5 bg-gray-900 border border-gray-850 rounded-xl relative">
                  <span className="p-1 px-1.5 bg-emerald-500/10 text-emerald-400 text-[9px] font-mono rounded font-bold uppercase">KAIZEN COMPLIANT</span>
                  <h4 className="font-sans font-bold text-white mt-2 text-xs">Lean Assembly Line Value Stream Layouts</h4>
                  <p className="text-[11px] text-gray-450 mt-1">SOP structural modeling. Eliminates waste and simplifies high-speed conveyor checkpoints.</p>
                </div>

                <div className="p-5 bg-gray-900 border border-gray-850 rounded-xl relative">
                  <span className="p-1 px-1.5 bg-amber-400/10 text-amber-400 text-[9px] font-mono rounded font-bold uppercase">INDUSTRIAL DIGITAL TWIN</span>
                  <h4 className="font-sans font-bold text-white mt-2 text-xs">Predictive Maintenance AI diagnostics with SAP PM</h4>
                  <p className="text-[11px] text-gray-450 mt-1">Configure telemetry anomaly algorithms. Track mechanical stress points automatically.</p>
                </div>
              </div>
            </div>

          </div>

          {/* Right Column: Track Features Spotlights & Calendar */}
          <div className="space-y-6">
            
            {/* Audience specific workspace tool */}
            <div className="p-6 bg-gradient-to-br from-[#0F1626] to-[#0A0D15] border border-amber-500/25 rounded-2xl relative overflow-hidden">
              <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest font-bold">TAILORED TRACK COMPLIANCE</span>
              
              {user.role === 'fresher' && (
                <div className="mt-4">
                  <h4 className="font-sans font-bold text-white text-base">Mock Interview Simulator Bot</h4>
                  <p className="text-xs text-gray-400 mt-1 leading-normal">
                    Practice core behavioral & domain questions. Our assistant analyzes your keywords against multinational criteria checks.
                  </p>
                  <button 
                    onClick={onOpenAITutor}
                    className="w-full text-center mt-4 py-2 px-3 bg-amber-400 text-gray-950 font-bold rounded-lg text-xs uppercase tracking-wider cursor-pointer"
                  >
                    Open Simulator Mock
                  </button>
                </div>
              )}

              {user.role === 'experienced' && (
                <div className="mt-4">
                  <h4 className="font-sans font-bold text-white text-base">Digital Domain Sandbox Projects</h4>
                  <p className="text-xs text-gray-400 mt-1 leading-normal">
                    Connect design portfolios directly with active sandbox testing. Compile STM32 codes and test ETAP grid calculations instantly.
                  </p>
                  <button 
                    onClick={onOpenAITutor}
                    className="w-full text-center mt-4 py-2 px-3 bg-amber-400 text-gray-950 font-bold rounded-lg text-xs uppercase tracking-wider cursor-pointer"
                  >
                    Launch Core Sandbox
                  </button>
                </div>
              )}

              {user.role === 'manager' && (
                <div className="mt-4">
                  <h4 className="font-sans font-bold text-white text-base">Executive Leadership Case Studies</h4>
                  <p className="text-xs text-gray-400 mt-1 leading-normal">
                    Review comprehensive plant layouts & digital transition case books detailing waste audits in FAANG or premium automotive factories.
                  </p>
                  <button 
                    onClick={onOpenAITutor}
                    className="w-full text-center mt-4 py-2 px-3 bg-amber-400 text-gray-950 font-bold rounded-lg text-xs uppercase tracking-wider cursor-pointer"
                  >
                    Open Executive Case Library
                  </button>
                </div>
              )}
            </div>

            {/* Simulated Live Session Calendar */}
            <div className="bg-gray-900 border border-gray-850 p-6 rounded-2xl">
              <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono flex items-center gap-1.5 border-b border-gray-800 pb-3 mb-4">
                <Calendar className="h-4 w-4 text-emerald-400" /> Live Session Webinar Calendar
              </h4>
              
              <div className="space-y-4">
                <div className="flex gap-3 text-xs">
                  <div className="bg-[#121E19] text-emerald-450 font-mono font-bold p-2.5 rounded-lg text-center leading-tight shrink-0 h-fit">
                    MAY<br />27
                  </div>
                  <div>
                    <h5 className="font-bold text-white leading-snug">EV Technology & Battery Management Systems</h5>
                    <p className="text-[10px] text-gray-400 mt-0.5">Live Webinar @ 7:00 PM CST (Satish Abraham)</p>
                  </div>
                </div>

                <div className="flex gap-3 text-xs">
                  <div className="bg-[#1A1211] text-amber-500/80 font-mono font-bold p-2.5 rounded-lg text-center leading-tight shrink-0 h-fit">
                    JUN<br />02
                  </div>
                  <div>
                    <h5 className="font-bold text-white leading-snug">Continuous Quality Audits: Six Sigma Green Belt DMAIC</h5>
                    <p className="text-[10px] text-gray-400 mt-0.5">Mock panel interactive clinic</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Certificate Status Tracker */}
            <div className="bg-gray-900 border border-gray-850 p-6 rounded-2xl">
              <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-3">
                Blockchain Certificate Wallet
              </h4>
              
              {user.role === 'fresher' ? (
                <div className="text-center p-4 bg-gray-950 border border-gray-800 rounded-xl">
                  <p className="text-xs text-gray-400 leading-normal">
                    Complete your in-progress course, achieve 80% on mock diagnostics exams, and submit your capstone modules to unlock your credential.
                  </p>
                </div>
              ) : (
                <div className="space-y-3">
                  <div className="p-3.5 bg-emerald-950/10 border border-emerald-500/20 rounded-xl flex items-center justify-between text-xs">
                    <div>
                      <div className="font-bold text-white">Green Belt Lean Six Sigma Practitioner</div>
                      <span className="text-[10px] text-gray-400 font-mono block">Acquired on 2026-02-14</span>
                    </div>
                    <Award className="h-5 w-5 text-emerald-400 shrink-0" />
                  </div>
                </div>
              )}
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
