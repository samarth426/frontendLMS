import React, { useState } from 'react';
import { ViewState } from '../types';
import { 
  Briefcase, 
  TrendingUp, 
  Award, 
  CheckCircle, 
  ArrowLeft, 
  Search, 
  CheckCircle2, 
  ArrowRight, 
  LineChart, 
  ChevronRight,
  GraduationCap
} from 'lucide-react';
import { motion } from 'motion/react';
import { RECRUITERS, PLACEMENT_STATS } from '../data/courses';

interface PlacementPageProps {
  setView: (view: ViewState) => void;
}

export default function PlacementPage({ setView }: PlacementPageProps) {
  const [selectedBranch, setSelectedBranch] = useState<string>('All');
  const [connectSuccess, setConnectSuccess] = useState(false);
  const [searchMail, setSearchMail] = useState('');

  const filteredStats = selectedBranch === 'All' 
    ? PLACEMENT_STATS 
    : PLACEMENT_STATS.filter(s => s.branch === selectedBranch);

  const handleConnectFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchMail.trim()) {
      setConnectSuccess(true);
      setSearchMail('');
      setTimeout(() => setConnectSuccess(false), 5000);
    }
  };

  const branches = ['All', 'Electrical', 'Mechanical', 'Civil', 'Electronics', 'EC', 'Computer'];

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 py-12" id="placement-page-root">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Back navigation */}
        <button 
          onClick={() => setView({ type: 'home' })}
          className="inline-flex items-center space-x-2 text-xs text-gray-400 hover:text-amber-400 font-mono transition-colors mb-8 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Landing Dashboard</span>
        </button>

        {/* Hero header */}
        <div className="mb-12 border-b border-gray-850 pb-8 text-center max-w-3xl mx-auto">
          <span className="font-mono text-xs uppercase font-extrabold text-amber-400 tracking-widest bg-amber-400/10 px-3 py-1 rounded-full border border-amber-400/20">
            Certified Corporate Placements Dashboard
          </span>
          <h1 className="text-3xl sm:text-4xl font-sans font-extrabold text-white mt-4 tracking-tight">
            Our Placements & Career Operations
          </h1>
          <p className="text-sm text-gray-400 mt-2">
            Every Sixsigma AI PG program is combined with real recruitment outreach and live evaluation support. Explore continuous student results below.
          </p>
        </div>

        {/* Live Placement counters */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
          <div className="bg-gradient-to-br from-gray-900 to-gray-950 border border-gray-800 p-6 rounded-2xl relative overflow-hidden">
            <span className="text-[10px] text-gray-400 uppercase font-mono font-bold">TOTAL ALUMNI PLACED</span>
            <div className="text-4xl font-extrabold text-white tracking-tight mt-1">5,200+</div>
            <p className="text-[11px] text-gray-500 mt-2 font-mono">Globally verified on blockchain networks</p>
          </div>

          <div className="bg-gradient-to-br from-gray-900 to-gray-955 border border-amber-500/20 p-6 rounded-2xl relative overflow-hidden">
            <div className="absolute right-0 top-0 h-10 w-10 bg-amber-500/10 rounded-full blur-xl" />
            <span className="text-[10px] text-amber-400 uppercase font-mono font-bold">AVG PLACEMENT RATE</span>
            <div className="text-4xl font-extrabold text-white tracking-tight mt-1">85% - 94%</div>
            <p className="text-[11px] text-gray-450 mt-2 font-mono">Within 180 days of course completion</p>
          </div>

          <div className="bg-gradient-to-br from-gray-900 to-gray-950 border border-gray-800 p-6 rounded-2xl relative overflow-hidden">
            <span className="text-[10px] text-gray-400 uppercase font-mono font-bold">TOP GLOBAL COMPENSATION</span>
            <div className="text-4xl font-extrabold text-white tracking-tight mt-1">₹25 LPA</div>
            <p className="text-[11px] text-gray-400 mt-2 font-mono">Computer Engineering / MLOps Track</p>
          </div>
        </div>

        {/* Interactive Stats filtering */}
        <div className="bg-gray-900 border border-gray-850 p-6 rounded-2xl mb-12">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 border-b border-gray-800 pb-5 mb-6">
            <div>
              <h3 className="font-bold text-white text-base">Select Branch to Filter Salaries</h3>
              <p className="text-xs text-gray-400 mt-1">See highest package and placement rate benchmarks per specialization branch.</p>
            </div>

            {/* Selector list */}
            <div className="flex flex-wrap gap-1.5">
              {branches.map(b => (
                <button
                  key={b}
                  onClick={() => setSelectedBranch(b)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold uppercase tracking-wider transition-all font-mono border cursor-pointer ${
                    selectedBranch === b 
                      ? 'bg-amber-400 text-gray-950 border-amber-400 font-bold' 
                      : 'bg-gray-850 text-gray-300 border-gray-800 hover:bg-gray-800'
                  }`}
                >
                  {b}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredStats.map((stat) => (
              <div key={stat.branch} className="p-5 bg-black/40 border border-gray-800 rounded-xl relative overflow-hidden">
                <span className="text-[10px] font-mono font-bold text-amber-400 uppercase tracking-widest">BRANCH BENCHMARK</span>
                <h4 className="text-base font-bold text-white font-sans mt-0.5">{stat.branch} Engineering</h4>

                <div className="grid grid-cols-2 gap-4 border-y border-gray-800 py-3 my-4 text-xs font-mono">
                  <div>
                    <div className="text-gray-500 text-[10px] uppercase">Highest CTC</div>
                    <div className="font-extrabold text-amber-300 mt-0.5 text-sm">{stat.highestPackage}</div>
                  </div>
                  <div>
                    <div className="text-gray-500 text-[10px] uppercase">Class Average</div>
                    <div className="font-extrabold text-white mt-0.5 text-sm">{stat.averagePackage}</div>
                  </div>
                </div>

                <div className="flex justify-between items-center text-xs font-mono">
                  <span className="text-gray-450">Overall Placement Ratio:</span>
                  <strong className="text-emerald-400">{stat.placementRate}%</strong>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Support Services Split-Down for Audience */}
        <div className="mb-12">
          <h2 className="text-xl font-sans font-bold text-white mb-8 text-center">Audience Specific Placements Architecture</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            
            {/* Freshers Support block */}
            <div className="p-6 bg-gradient-to-b from-gray-900 to-gray-950 border border-gray-800 rounded-2xl flex flex-col justify-between">
              <div>
                <span className="p-2.5 bg-blue-500/10 text-blue-400 w-fit rounded-xl font-extrabold text-lg block mb-4">🎓</span>
                <h3 className="font-sans font-extrabold text-white text-base">For Freshers & Early Career</h3>
                <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                  Tailored direct assistance to help you break into tier-1 industries straight out of college. We guarantee interviews and build a top-tier GitHub portfolio.
                </p>

                <ul className="mt-5 space-y-3 text-xs text-gray-300 font-sans">
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Professional Resume & LinkedIn SEO Optimization.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Full-stack aptitude testing and evaluation coaching.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>3 detailed mock panels led by active developers.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Direct priority placement drives with 200+ partners.</span>
                  </li>
                </ul>
              </div>

              <div className="border-t border-gray-800 mt-6 pt-5">
                <button 
                  onClick={() => setView({ type: 'programmes', audience: 'fresher' })}
                  className="text-xs font-bold text-amber-400 font-mono hover:underline flex items-center gap-1 cursor-pointer"
                >
                  Join Fresher Program <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Experienced Support block */}
            <div className="p-6 bg-gradient-to-b from-gray-900 to-gray-955 border border-amber-500/20 rounded-2xl flex flex-col justify-between">
              <div>
                <span className="p-2.5 bg-amber-500/10 text-amber-400 w-fit rounded-xl font-extrabold text-lg block mb-4">💼</span>
                <h3 className="font-sans font-extrabold text-white text-base">For Experienced Professionals</h3>
                <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                  Engineered to help working professionals secure core design roles or transition seamlessly between industries without career gaps.
                </p>

                <ul className="mt-5 space-y-3 text-xs text-gray-300 font-sans">
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>1-on-1 career design & domain shift mapping.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Branding you as a Senior Technical Lead.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>5 Rounds detailed structural mock tests.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Salary negotiation consulting to secure the maximum offer.</span>
                  </li>
                </ul>
              </div>

              <div className="border-t border-amber-500/10 mt-6 pt-5">
                <button 
                  onClick={() => setView({ type: 'programmes', audience: 'experienced' })}
                  className="text-xs font-bold text-amber-400 font-mono hover:underline flex items-center gap-1 cursor-pointer"
                >
                  Join Experienced Program <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>

            {/* Managers Support block */}
            <div className="p-6 bg-gradient-to-b from-gray-900 to-gray-950 border border-gray-800 rounded-2xl flex flex-col justify-between">
              <div>
                <span className="p-2.5 bg-emerald-500/10 text-emerald-400 w-fit rounded-xl font-extrabold text-lg block mb-4">🧑‍💼</span>
                <h3 className="font-sans font-extrabold text-white text-base">For Executive Managers</h3>
                <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                  Elite network connects to place senior professionals as directors, L&D managers, sixsigma consultants, or operating directors.
                </p>

                <ul className="mt-5 space-y-3 text-xs text-gray-300 font-sans">
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Exclusive virtual cohort dinners and group connections.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Direct connection to corporate headhunters and executive recruiters.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>1-on-1 executive coaching focusing on modern P&L.</span>
                  </li>
                  <li className="flex gap-2">
                    <span className="text-amber-400 font-bold">•</span>
                    <span>Tuition alignment support for company sponsorships.</span>
                  </li>
                </ul>
              </div>

              <div className="border-t border-gray-800 mt-6 pt-5">
                <button 
                  onClick={() => setView({ type: 'programmes', audience: 'manager' })}
                  className="text-xs font-bold text-amber-400 font-mono hover:underline flex items-center gap-1 cursor-pointer"
                >
                  Join Leader Program <ChevronRight className="h-4 w-4" />
                </button>
              </div>
            </div>

          </div>
        </div>

        {/* Contact panel */}
        <div className="bg-gradient-to-br from-[#0B1221] to-gray-950 border border-gray-850 p-8 rounded-3xl">
          <div className="max-w-2xl mx-auto text-center">
            <h3 className="text-xl font-sans font-extrabold text-white">Join the Next Recruitment Drive Group</h3>
            <p className="text-xs text-gray-400 mt-1.5">
              Submit your corporate profile email. Our placement managers will review your experience and match you with 3 partner profiles within 24 hours.
            </p>

            <form onSubmit={handleConnectFormSubmit} className="mt-6 flex flex-col sm:flex-row gap-3">
              <input 
                type="email" 
                required
                value={searchMail}
                onChange={(e) => setSearchMail(e.target.value)}
                placeholder="Enter your professional email (e.g. Ramesh@outlook.com)" 
                className="bg-gray-900 border border-gray-800 focus:border-amber-400 rounded-xl px-4 py-3 placeholder-gray-500 text-xs flex-grow focus:outline-none text-white font-mono"
              />
              <button 
                type="submit"
                className="px-6 py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-black rounded-xl text-xs uppercase tracking-wide shrink-0 transition-all shadow-md cursor-pointer"
              >
                Match My Resume
              </button>
            </form>

            {connectSuccess && (
              <div className="mt-4 p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-xs rounded-xl font-mono">
                ✔ Match scheduled! Standard checklist confirmation sent to email. Keep your portfolio link ready!
              </div>
            )}
          </div>
        </div>

      </div>
    </div>
  );
}
