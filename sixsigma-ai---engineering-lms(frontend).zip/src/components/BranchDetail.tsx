import { useState } from 'react';
import { ViewState } from '../types';
import { 
  ArrowLeft, 
  Clock, 
  GraduationCap, 
  Cpu, 
  HelpCircle, 
  Award, 
  Layers, 
  Wrench, 
  Briefcase, 
  CreditCard, 
  Sliders, 
  Zap,
  CheckCircle2, 
  ArrowRight,
  Download,
  Users2,
  Bookmark
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { BRANCHES_DATA } from '../data/courses';

interface BranchDetailProps {
  branchId: string;
  setView: (view: ViewState) => void;
}

export default function BranchDetail({ branchId, setView }: BranchDetailProps) {
  const [activeTab, setActiveTab] = useState<'6m' | '1y'>('6m');
  const [downloadSuccessEnrolled, setDownloadSuccessEnrolled] = useState(false);

  const branch = BRANCHES_DATA.find(b => b.id === branchId);

  if (!branch) {
    return (
      <div className="bg-[#090D15] p-12 text-center text-white font-sans">
        <Bookmark className="h-12 w-12 text-red-400 mx-auto mb-4" />
        <h3 className="text-xl font-bold">Branch ID not found</h3>
        <button onClick={() => setView({ type: 'home' })} className="mt-4 text-xs text-amber-400 font-mono">
          Return Home
        </button>
      </div>
    );
  }

  const handleEnrollClick = (type: string, price: number) => {
    setView({
      type: 'checkout',
      plan: {
        name: `${branch.name} - ${type}`,
        price,
        type,
        branchId: branch.id
      }
    });
  };

  const simulateBrochureDownload = () => {
    setDownloadSuccessEnrolled(true);
    setTimeout(() => {
      setDownloadSuccessEnrolled(false);
    }, 4500);
  };

  return (
    <div className="bg-[#090D15] min-h-screen text-gray-200 py-12" id="branch-detail-root">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Back navigation */}
        <button 
          onClick={() => setView({ type: 'home' })}
          className="inline-flex items-center space-x-2 text-xs text-gray-400 hover:text-amber-400 font-mono transition-colors mb-8 cursor-pointer"
        >
          <ArrowLeft className="h-4 w-4" />
          <span>Back to Landing Home</span>
        </button>

        {/* Header Block */}
        <div className="mb-12 border-b border-gray-800 pb-10">
          <span className="font-mono text-xs uppercase font-extrabold text-amber-400 block tracking-widest mb-1">
            Engineering Specialisation Detailed Panel
          </span>
          <h1 className="text-3xl sm:text-5xl font-sans font-extrabold text-white tracking-tight">
            {branch.name}
          </h1>
          <p className="text-base sm:text-lg text-gray-450 mt-2 max-w-3xl font-medium">
            {branch.tagline}
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex border-b border-gray-850 mb-10 gap-2">
          <button
            onClick={() => setActiveTab('6m')}
            className={`px-6 py-4.5 text-xs sm:text-sm font-sans font-extrabold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center space-x-2 ${
              activeTab === '6m' 
                ? 'border-amber-400 bg-amber-400/5 text-white font-black' 
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <Clock className="h-4 w-4 text-amber-400" />
            <span>✔ PG Certificate — 6 Months</span>
          </button>
          <button
            onClick={() => setActiveTab('1y')}
            className={`px-6 py-4.5 text-xs sm:text-sm font-sans font-extrabold rounded-t-xl transition-all border-b-2 cursor-pointer flex items-center space-x-2 ${
              activeTab === '1y' 
                ? 'border-amber-400 bg-amber-400/5 text-white font-black' 
                : 'border-transparent text-gray-400 hover:text-gray-200'
            }`}
          >
            <Layers className="h-4 w-4 text-amber-400" />
            <span>✔ Advanced Professional Diploma — 1 Year</span>
          </button>
        </div>

        {/* Tabs Contents wrapper */}
        <AnimatePresence mode="wait">
          {activeTab === '6m' ? (
            <motion.div 
              key="6m-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-10"
              id="six-months-tab-view"
            >
              {/* Left 2 Columns containing curriculum & projects */}
              <div className="lg:col-span-2 space-y-10">
                
                {/* Duration eligibility summary block */}
                <div className="bg-gray-900 border border-gray-850 rounded-2xl p-6 sm:p-8">
                  <h3 className="text-lg font-sans font-bold text-white mb-4 flex items-center gap-2">
                    <Sliders className="h-5 w-5 text-amber-400" /> Programme Overview
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                    <div>
                      <div className="text-gray-500 font-mono text-[10px] uppercase">Duration & Attendance</div>
                      <div className="text-white font-bold mt-1 font-sans">{branch.certificate6m.duration}</div>
                    </div>
                    <div>
                      <div className="text-gray-500 font-mono text-[10px] uppercase">Eligibility Criteria</div>
                      <div className="text-white font-bold mt-1 font-sans">{branch.certificate6m.eligibility}</div>
                    </div>
                  </div>

                  <div className="mt-5 pt-5 border-t border-gray-800">
                    <div className="text-gray-500 font-mono text-[10px] uppercase">Who Should Enroll</div>
                    <p className="text-gray-300 mt-1">{branch.certificate6m.whoShouldEnroll}</p>
                  </div>
                </div>

                {/* Syllabus / Modules Grid */}
                <div>
                  <h3 className="text-lg font-sans font-bold text-white mb-6 flex items-center gap-2">
                    <GraduationCap className="h-5 w-5 text-amber-400" /> 6-Months Comprehensive Syllabus
                  </h3>
                  <div className="space-y-3">
                    {branch.certificate6m.syllabus.map((module, idx) => (
                      <div key={idx} className="bg-gray-900/60 p-4 border border-gray-850 rounded-xl flex gap-3 items-start">
                        <span className="p-1 px-2.5 bg-gray-800 rounded-md text-amber-400 font-mono text-xs font-bold leading-none mt-0.5">
                          #{idx + 1}
                        </span>
                        <div>
                          <h4 className="font-sans font-bold text-white text-sm">{module}</h4>
                          <p className="text-[11px] text-gray-450 mt-1 leading-normal">Deep analytical coverage, interactive notebook exercises & live assessment checklist.</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Capstone Projects */}
                <div>
                  <h3 className="text-lg font-sans font-bold text-white mb-5 flex items-center gap-2">
                    <Cpu className="h-5 w-5 text-amber-400" /> Capstone Portfolio Projects
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {branch.certificate6m.capstone.map((proj, idx) => (
                      <div key={idx} className="bg-[#121B2D] border border-blue-900/40 p-5 rounded-xl">
                        <span className="text-[10px] font-mono font-bold text-blue-400 uppercase tracking-widest block mb-2">PROJECT #{idx + 1}</span>
                        <div className="font-bold text-white text-xs leading-snug">{proj}</div>
                        <p className="text-[10px] text-gray-400 mt-2">Required submission with live evaluation panel grading.</p>
                      </div>
                    ))}
                  </div>
                </div>

              </div>

              {/* Right Sidebar containing tools, placement, fee & CTA */}
              <div className="space-y-6">
                
                {/* Tools & Tech card */}
                <div className="bg-gray-900/40 border border-gray-850 p-6 rounded-2xl">
                  <h4 className="font-bold text-white text-xs uppercase tracking-wide flex items-center gap-2 font-mono mb-4">
                    <Wrench className="h-4 w-4 text-amber-400" /> Tools & Platforms Mastered
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {branch.certificate6m.tools.map((t, idx) => (
                      <span key={idx} className="text-xs bg-gray-800 px-3 py-1.5 rounded-lg border border-gray-700 text-gray-300 font-medium">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Placement support card */}
                <div className="bg-emerald-950/20 border border-emerald-500/20 p-6 rounded-2xl">
                  <h4 className="font-bold text-white text-xs uppercase tracking-wide flex items-center gap-2 font-mono mb-4 text-emerald-400">
                    <Briefcase className="h-4 w-4" /> Placement Support Guaranteed
                  </h4>
                  <ul className="space-y-3.5 text-xs text-gray-300">
                    {branch.certificate6m.placementSupport.map((support, idx) => (
                      <li key={idx} className="flex gap-2 items-start leading-normal">
                        <CheckCircle2 className="h-4 w-4 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{support}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Easy pricing options & direct checkout CTA */}
                <div className="bg-gradient-to-br from-gray-900 to-gray-950 border border-amber-500/30 p-6 rounded-2xl relative overflow-hidden">
                  <div className="absolute right-0 bottom-0 h-20 w-20 bg-amber-500/5 rounded-full blur-2xl" />
                  <span className="text-[10px] font-mono text-amber-400 uppercase tracking-widest font-bold">TUITION FEES & SCHOLARSHIP</span>
                  <div className="text-3xl font-extrabold text-white mt-1">{branch.certificate6m.fee.split('|')[0].trim()}</div>
                  <div className="text-xs text-gray-400 mt-1 font-mono mb-6">{branch.certificate6m.fee.split('|')[1]?.trim() || 'Easy EMI Options Available'}</div>

                  <div className="space-y-3">
                    <button 
                      onClick={() => handleEnrollClick('PG Certificate', 45000)}
                      className="w-full text-center py-3 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-500 hover:to-amber-600 text-gray-950 font-black rounded-lg text-xs uppercase tracking-wide shadow-lg shadow-amber-500/5 cursor-pointer"
                    >
                      Enroll Now & Start Pilot
                    </button>

                    <button 
                      onClick={simulateBrochureDownload}
                      className="w-full text-center py-2.5 bg-gray-900 hover:bg-gray-800 text-gray-300 font-bold rounded-lg text-[11px] uppercase tracking-wide border border-gray-800 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Download Syllabus Outline</span>
                    </button>
                  </div>

                  {downloadSuccessEnrolled && (
                    <div className="mt-4 p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono rounded text-center">
                      ✔ Check local browser downloads catalog for brochure!
                    </div>
                  )}
                </div>

              </div>
            </motion.div>
          ) : (
            <motion.div 
              key="1y-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              className="grid grid-cols-1 lg:grid-cols-3 gap-10"
              id="one-year-tab-view"
            >
              {/* Left 2 Columns containing curriculum & specialized tracks */}
              <div className="lg:col-span-2 space-y-10">
                
                {/* Overview block */}
                <div className="bg-gray-900 border border-gray-850 rounded-2xl p-6 sm:p-8">
                  <h3 className="text-lg font-sans font-bold text-white mb-4 flex items-center gap-2">
                    <Sliders className="h-5 w-5 text-amber-400" /> Core Diploma Parameters
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs mb-5">
                    <div>
                      <div className="text-gray-500 font-mono text-[10px] uppercase">Duration & Attendance</div>
                      <div className="text-white font-bold mt-1 font-sans">{branch.diploma1y.duration}</div>
                    </div>
                    <div>
                      <div className="text-gray-500 font-mono text-[10px] uppercase">Target Audience Levels</div>
                      <div className="text-white font-bold mt-1 font-sans">{branch.diploma1y.eligibility}</div>
                    </div>
                  </div>

                  <p className="text-xs text-gray-300 border-l border-amber-500/30 pl-3 italic">
                    "{branch.diploma1y.whoShouldEnroll}"
                  </p>
                </div>

                {/* 3 Specialisation Tracks */}
                <div>
                  <h3 className="text-lg font-sans font-bold text-white mb-6 flex items-center gap-2">
                    <Users2 className="h-5 w-5 text-amber-400" /> 3 Customized Participant Tracks
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    {branch.diploma1y.tracks.map((trackText, idx) => (
                      <div key={idx} className="bg-gray-900 border border-gray-850 p-5 rounded-2xl">
                        <span className="p-1 bg-amber-400/20 text-cream rounded font-mono text-[9px] text-amber-300 font-bold">TRACK LEVEL #{idx + 1}</span>
                        <p className="text-xs text-gray-200 font-bold mt-3 leading-snug">{trackText}</p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Year Long Curriculum Modules */}
                <div>
                  <h3 className="text-lg font-sans font-bold text-white mb-6 flex items-center gap-2">
                    <GraduationCap className="h-5 w-5 text-amber-400" /> 12-Month Year-Long Syllabus Masterplan
                  </h3>
                  <div className="space-y-3">
                    {branch.diploma1y.curriculum.map((item, idx) => (
                      <div key={idx} className="bg-gray-900/60 p-4 border border-gray-850 rounded-xl flex gap-3 items-center">
                        <span className="text-[10px] font-mono font-bold bg-gray-850 border border-gray-800 text-amber-400 px-2 py-1 rounded">
                          Month {idx + 1 <= 9 ? `0${idx + 1}` : idx + 1}
                        </span>
                        <div className="font-sans font-bold text-white text-sm">
                          {item}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Industry Expert Faculty & Outcomes */}
                <div className="p-6 bg-gradient-to-r from-blue-900/10 to-indigo-900/5 border border-indigo-900/40 rounded-2xl flex flex-col sm:flex-row justify-between gap-6 items-center">
                  <div>
                    <h4 className="font-bold text-white mb-1 text-sm">Live Hackathons & Industry Expert Faculty</h4>
                    <p className="text-xs text-gray-400 max-w-xl">
                      Includes 2 industry expert team assignments, 1 major hackathon sandbox submission, and weekly doubt-clarifying webinars led by active engineering directors.
                    </p>
                  </div>
                  <span className="text-xs font-mono font-bold text-blue-400 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full uppercase tracking-wider shrink-0">
                    Blockchain Certified
                  </span>
                </div>

              </div>

              {/* Right Sidebar containing core skills, sector targets, job roles, fee & corporate options */}
              <div className="space-y-6">
                
                {/* Core skills card */}
                <div className="bg-gray-900/40 border border-gray-850 p-6 rounded-2xl">
                  <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-4">
                    Core Skills Acquired
                  </h4>
                  <ul className="space-y-3.5 text-xs text-gray-300">
                    {branch.diploma1y.coreSkills.map((skill, idx) => (
                      <li key={idx} className="flex gap-2">
                        <span className="text-amber-400">•</span>
                        <span>{skill}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Tools & Tech card */}
                <div className="bg-gray-900/40 border border-gray-850 p-6 rounded-2xl">
                  <h4 className="font-bold text-white text-xs uppercase tracking-wide flex items-center gap-2 font-mono mb-4">
                    <Wrench className="h-4 w-4 text-emerald-400" /> Mastered Application Tools
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {branch.diploma1y.tools.map((t, idx) => (
                      <span key={idx} className="text-xs bg-gray-800 px-3 py-1.5 rounded-lg border border-gray-700 text-gray-350 font-medium">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Target Sectors & Target Roles */}
                <div className="bg-gray-900/40 border border-gray-850 p-6 rounded-2xl space-y-5">
                  <div>
                    <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-2">
                      Target Job Sectors
                    </h4>
                    <div className="text-xs text-gray-400 leading-relaxed font-sans">{branch.diploma1y.targets.join(', ')}</div>
                  </div>
                  <div className="border-t border-gray-800 pt-4">
                    <h4 className="font-bold text-white text-xs uppercase tracking-wide font-mono mb-2">
                      Graduate Roles
                    </h4>
                    <div className="text-xs text-gray-400 leading-relaxed font-sans">{branch.diploma1y.roles.join(', ')}</div>
                  </div>
                </div>

                {/* Fee & Corporate options card */}
                <div className="bg-gradient-to-br from-gray-900 to-gray-950 border border-emerald-500/30 p-6 rounded-2xl relative overflow-hidden">
                  <span className="text-[10px] font-mono text-emerald-400 uppercase tracking-widest font-bold">12-MONTH DIPLOMA TUITION</span>
                  <div className="text-3xl font-extrabold text-white mt-1">{branch.diploma1y.fee.split('|')[0].trim()}</div>
                  <div className="text-xs text-gray-400 mt-1 font-mono mb-4">{branch.diploma1y.fee.split('|')[1]?.trim() || 'Zero-Cost EMI Inquire'}</div>

                  <p className="text-[11px] text-gray-450 leading-normal mb-6">
                    ✔ Ready for direct Corporate Sponsorship & Tuition reimbursement grants. Standard invoices provided on registration.
                  </p>

                  <div className="space-y-3">
                    <button 
                      onClick={() => handleEnrollClick('Advanced Diploma', 85000)}
                      className="w-full text-center py-3 bg-gradient-to-r from-emerald-400 to-emerald-500 hover:from-emerald-500 hover:to-emerald-600 text-gray-950 font-black rounded-lg text-xs uppercase tracking-wide shadow-lg cursor-pointer"
                    >
                      Apply Now & Start Pilot
                    </button>

                    <button 
                      onClick={simulateBrochureDownload}
                      className="w-full text-center py-2.5 bg-gray-900 hover:bg-gray-800 text-gray-300 font-bold rounded-lg text-[11px] uppercase tracking-wide border border-gray-800 flex items-center justify-center gap-2 cursor-pointer"
                    >
                      <Download className="h-3.5 w-3.5" />
                      <span>Download Academic Brochure</span>
                    </button>
                  </div>

                  {downloadSuccessEnrolled && (
                    <div className="mt-4 p-2 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-mono rounded text-center animate-fade-in">
                      ✔ Brochure saved locally! Speak with an advisor for active batches.
                    </div>
                  )}
                </div>

              </div>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
