import { BranchInfo, Testimonial, PlacementStat } from '../types';

export const BRANCHES_DATA: BranchInfo[] = [
  {
    id: 'electrical',
    name: 'Electrical Engineering',
    icon: 'Zap',
    color: 'from-amber-400 to-yellow-600',
    tagline: 'Become an Industry-Ready Electrical & EV Specialist',
    description: 'Master power systems grid integration, electrical automations, EV battery management and diagnostics using tools like ETAP and MATLAB.',
    certificate6m: {
      duration: '6 Months | Online + Live Sessions | Batch starts next Mon',
      eligibility: 'BE / B.Tech EE — Freshers (0–2 yrs) & Early-Career (2–5 yrs)',
      whoShouldEnroll: 'Early grads, job-seekers and power professionals wanting custom technical upgrades.',
      syllabus: [
        'Power Systems & Smart Grid Fundamentals',
        'Electrical Machines & Drives (AI-Assisted Diagnostics)',
        'PLC, SCADA & Industrial Automation',
        'Power Electronics & Inverter Design',
        'Energy Management, Audit & ISO 50001',
        'Python for Electrical Engineers',
        'MATLAB / Simulink for Power Systems'
      ],
      capstone: [
        'Smart Microgrid Integration Project',
        'Industrial SCADA & Motor Diagnostics Sandbox',
        'ISO 50001 Thermal Plant Compliance Audit'
      ],
      tools: ['MATLAB', 'Simulink', 'PowerWorld', 'Excel Solver', 'Python'],
      placementSupport: [
        'Resume & LinkedIn Profile Optimisation',
        'Aptitude + EE Domain Test Coaching',
        'Technical Mock Interviews — 3 Rounds',
        'Placement within 3 months guaranteed of completion'
      ],
      fee: '₹45,000 | Easy EMI from ₹3,750/mo'
    },
    diploma1y: {
      duration: '12 Months | Online + Blended | Weekend Batches',
      eligibility: 'BE / B.Tech / M.Tech EE — All Levels (Freshers → Managers)',
      whoShouldEnroll: 'Engineers wanting deep domain command, EV specialisation or corporate manager tracks without career breaks.',
      tracks: [
        '🎓 FRESHER TRACK: Career Jumpstart & Core Placement Sprint',
        '💼 EXPERIENCED TRACK: Domain Deepening + Industrial AI + Executive Credentials',
        '🧑‍💼 MANAGER TRACK: Engineering Strategy + Industry 4.0 + P&L Leadership'
      ],
      curriculum: [
        'Advanced Power Systems & Renewable Energy Integration',
        'EV Technology & Battery Management Systems (BMS)',
        'AI / ML for Predictive Maintenance in Electrical Assets',
        'IoT-Based Smart Building & Energy Automation',
        'High Voltage Engineering & Electrical Safety',
        'Digital Twin for Electrical Networks (ETAP / DIgSILENT)',
        'Six Sigma & Lean for Electrical Manufacturing',
        'Project Management & Agile for Engineers',
        'Leadership & Strategic Decision-Making for Electrical Managers'
      ],
      coreSkills: [
        'Power Grid Scheduling',
        'EV Powertrain System Engineering',
        'IoT-BMS Architecture',
        'SCADA Integration Protocols',
        'Predictive Maintenance AI models'
      ],
      tools: ['ETAP', 'DIgSILENT', 'AutoCAD Electrical', 'MATLAB/Simulink', 'Python', 'SAP PM'],
      targets: ['Power Utilities', 'EV & Mobility Manufacturers', 'Renewable Energy Developers', 'Defence Labs'],
      roles: ['Electrical Engineer', 'Automation Lead', 'EV Systems Engineer', 'Smart Grid Analyst', 'Power Asset Director'],
      fee: '₹85,000 | Zero-Cost EMI from ₹7,080/mo'
    }
  },
  {
    id: 'mechanical',
    name: 'Mechanical Engineering',
    icon: 'Settings',
    color: 'from-blue-500 to-indigo-600',
    tagline: 'Drive Advanced Mechanical Design and Industry 4.0 Robotics',
    description: 'Upgrade to modern product design (CAD/CAM), ANSYS simulation, additive manufacturing, and Lean Process Control systems.',
    certificate6m: {
      duration: '6 Months | Online + Live Sessions | Evening Batches Available',
      eligibility: 'BE / B.Tech ME — Freshers (0–2 yrs) & Early-Career (2–5 yrs)',
      whoShouldEnroll: 'Mechanical graduates lacking exposure to modern tools like CATIA or ANSYS FEA.',
      syllabus: [
        'CAD/CAM & Product Design (SolidWorks / CATIA)',
        'Manufacturing Processes & Quality Control (SPC, FMEA)',
        'Thermodynamics & Fluid Mechanics Applications',
        'Industrial IoT & Condition Monitoring',
        'Six Sigma Green Belt Foundation (DMAIC)',
        'Python for Mechanical Engineers',
        'FEA Basics using ANSYS'
      ],
      capstone: [
        'High-Pressure Piping Structural FEA',
        'DMAIC Scrap Rate Reduction Project',
        'Brake Caliper Topology Optimization'
      ],
      tools: ['SolidWorks', 'ANSYS Mechanical', 'Minitab', 'Python', 'AutoCAD'],
      placementSupport: [
        'Resume Overhaul with Design Portfolio',
        'Aptitude & Quality Engineering Tests',
        '3 Rounds Technical Mock Interviews',
        'Dedicated Mech Recruiter Matchmaking'
      ],
      fee: '₹48,000 | Easy EMI from ₹4,000/mo'
    },
    diploma1y: {
      duration: '12 Months | Online + Blended | Weekend Batches',
      eligibility: 'BE / B.Tech / M.Tech ME — All Levels (Freshers → Managers)',
      whoShouldEnroll: 'Designers, manufacturing supervisors and managers aiming for smart-factory leadership.',
      tracks: [
        '🎓 FRESHER TRACK: Digital Design Mastery + Core Mechanical Placements',
        '💼 EXPERIENCED TRACK: Hyper-Specialisation in Robotics & Cobots',
        '🧑‍💼 MANAGER TRACK: Operations Management, Supply Chain & PMP Strategy'
      ],
      curriculum: [
        'Advanced Manufacturing & Industry 4.0 Integration',
        'AI / ML for Predictive Maintenance & Quality AI',
        'Robotics & Collaborative Robots (Cobots)',
        'Digital Twin & Simulation (ANSYS / Siemens NX)',
        'Lean Six Sigma Black Belt Programme',
        'Supply Chain & Operations Management',
        'Additive Manufacturing (3D Printing) Technologies',
        'Project Management (PMP Framework)',
        'Leadership & Strategic Decision-Making for Mechanical Managers'
      ],
      coreSkills: [
        'High Precision Product Design',
        'Cobots Programming & Safety',
        'Lean Assembly Workstation Layouts',
        'Simulation and Thermal Analysis',
        'Supply Chain Operations Management'
      ],
      tools: ['SolidWorks', 'CATIA', 'ANSYS Mechanical / Fluent', 'Siemens NX', 'Minitab', 'SAP PP/QM'],
      targets: ['Automotive, Aerospace, FMCG manufacturing, Defence, Oil & Gas giants'],
      roles: ['Design Engineer', 'Manufacturing Automation Architect', 'Plant Quality Manager', 'Technical Operations Head'],
      fee: '₹92,000 | Zero-Cost EMI from ₹7,660/mo'
    }
  },
  {
    id: 'civil',
    name: 'Civil Engineering',
    icon: 'Home',
    color: 'from-emerald-500 to-teal-600',
    tagline: 'Master Structural Design, Revit BIM, & Smart City Infrastructure',
    description: 'Transform traditional concrete methods into structural analysis pipelines, Revit BIM modulations, and P6 CPM Scheduling.',
    certificate6m: {
      duration: '6 Months | Hybrid + Live Projects | Weekend Batches',
      eligibility: 'BE / B.Tech CE — Freshers (0–2 yrs) & Early-Career (2–5 yrs)',
      whoShouldEnroll: 'Engineers who want to transition from supervisor roles to structural designers or quantity estimators.',
      syllabus: [
        'Structural Analysis & Design (STAAD.Pro / ETABS)',
        'AutoCAD & Revit for Civil Engineers',
        'Construction Project Management (CPM, PERT)',
        'Geotechnical Engineering & Foundation Design',
        'Quantity Surveying & Cost Estimation',
        'Environmental Engineering & Green Building (LEED)',
        'Python / Excel for Civil Data Analysis'
      ],
      capstone: [
        'Multi-Story Commercial Building Wind Design',
        'Comprehensive BIM Walkthrough & 3D Model',
        'WBS & CPM Cost-Estimation for Residential Community'
      ],
      tools: ['STAAD.Pro', 'ETABS', 'AutoCAD Civil 3D', 'Revit Structure', 'Microsoft Project'],
      placementSupport: [
        'BIM Portfolio Construction',
        'Civil Theory & Estimating Tests',
        'Real-world mock panel drills',
        'Connecting with 50+ Top Real Estate Firms'
      ],
      fee: '₹44,000 | Easy EMI from ₹3,660/mo'
    },
    diploma1y: {
      duration: '12 Months | Online + Blended | Specialized Smart Projects',
      eligibility: 'BE / B.Tech / M.Tech CE — Open to all candidates',
      whoShouldEnroll: 'Project executioners, builders, inspectors and executives looking to drive smart city frameworks.',
      tracks: [
        '🎓 FRESHER TRACK: AutoCAD/STAAD.Pro fast-track + BIM placement',
        '💼 EXPERIENCED TRACK: Advanced structural diagnostics + Earthquakes',
        '🧑‍💼 MANAGER TRACK: Contract Management, FIDIC & PMP leadership'
      ],
      curriculum: [
        'BIM — Building Information Modelling (Revit + Navisworks)',
        'AI & Drone Technology in Construction & Surveying',
        'Smart Infrastructure & IoT-Based Structural Monitoring',
        'Advanced Structural Design & Earthquake Engineering',
        'Contract Management, FIDIC & Dispute Resolution',
        'Urban Planning & Smart City Concepts',
        'Infrastructure Asset Management (IAM)',
        'Project Management Professional (PMP)',
        'Leadership for Construction & Infrastructure Managers'
      ],
      coreSkills: [
        'BIM Modeling Integrity',
        'Drone Scan Photogrammetry',
        'Structural Durability Diagnostics',
        'FIDIC Contract Claim Defense',
        'Multi-Tier Project Budgeting'
      ],
      tools: ['STAAD.Pro', 'ETABS', 'Revit', 'Navisworks Manage', 'Primavera P6', 'DroneDeploy', 'Python'],
      targets: ['Top Tier Real Estate Developers, Infrastructure Trusts, Smart City Consultancies, Public Works'],
      roles: ['Senior BIM Coordinator', 'Lead Structural Designer', 'Contracts & Claims Manager', 'Civil Project Director'],
      fee: '₹88,000 | Zero-Cost EMI from ₹7,330/mo'
    }
  },
  {
    id: 'electronics',
    name: 'Electronics Engineering',
    icon: 'Cpu',
    color: 'from-purple-500 to-indigo-600',
    tagline: 'PCB Masterclass, Embedded Firmware, & Edge TinyML Technologies',
    description: 'Go from schematic capture to manufacturing files with Altium, write real-time OS on ARM Cortex, and program edge computers.',
    certificate6m: {
      duration: '6 Months | Live Coding & Virtual HW Labs | Morning batches',
      eligibility: 'BE / B.Tech EE/ECE/EI — All graduates eligible',
      whoShouldEnroll: 'Hardware enthusiasts looking for professional Altium Designer & embedded C firmware training.',
      syllabus: [
        'Embedded Systems Design (ARM Cortex, Arduino, RaspPi)',
        'PCB Design & Layout (Altium / KiCad)',
        'VLSI Design Fundamentals (Verilog / VHDL)',
        'Signal Processing & DSP Applications',
        'Industrial Electronics & Power Devices',
        'Python for Electronics & Hardware Interfacing',
        'IoT Hardware Design & Prototyping'
      ],
      capstone: [
        '4-Layer IoT Controller Board Gerber Release',
        'Bare-Metal ARM Cortex DMA Driver Implementation',
        'Industrial Smart Meter PCB with RF Shielding'
      ],
      tools: ['Altium Designer', 'KiCad', 'ModelSim', 'Vivado STM32CubeIDE', 'Arduino IDE', 'Python'],
      placementSupport: [
        'Hardware Design Schema Portfolios',
        'Embedded C Coding assessment training',
        '3 Round Board Technical Reviews',
        'Hardware product house direct referrals'
      ],
      fee: '₹47,000 | Easy EMI from ₹3,910/mo'
    },
    diploma1y: {
      duration: '12 Months | Blended with Hardware Kit Shipping | Weekend sessions',
      eligibility: 'BE / B.Tech / M.Tech Electronics/Electrical — All levels',
      whoShouldEnroll: 'Professionals looking to shift into Semiconductors, ADAS Automotive, or medical IoT networks.',
      tracks: [
        '🎓 FRESHER TRACK: Schema drafting, layout & micro-controller placement',
        '💼 EXPERIENCED TRACK: AI at the edge, RTOS custom porting & VLSI simulation',
        '🧑‍💼 MANAGER TRACK: Go-to-market strategies, safety standards (AEC-Q) and tech teams guidance'
      ],
      curriculum: [
        'Advanced Embedded Systems & RTOS',
        'AI at the Edge — TinyML & Edge AI Deployment',
        'VLSI & Semiconductor Design Flow',
        'RF & Wireless Communication Systems',
        'Industrial IoT & Smart Sensor Networks',
        'Digital Twin for Electronic Systems',
        'Product Development Lifecycle & Go-to-Market',
        'Quality & Reliability Engineering (AEC-Q, IPC Standards)',
        'Leadership for Electronics Managers'
      ],
      coreSkills: [
        'RTOS Threading & Mutex management',
        'Edge ML weight quantisation',
        'High-Speed PCB impedance tuning',
        'Verilog IP Design and simulation'
      ],
      tools: ['Altium Designer', 'Xilinx Vivado', 'ModelSim', 'MATLAB', 'Python', 'C/C++', 'STM32CubeMX'],
      targets: ['Semiconductor Labs, Automotive Tier-1 houses, Aerospace HUD, Biotech diagnostics'],
      roles: ['Senior Embedded Architect', 'VLSI Design Lead', 'PCB Layout Specialist', 'Hardware Product Director'],
      fee: '₹95,000 | Zero-Cost EMI from ₹7,910/mo'
    }
  },
  {
    id: 'ec',
    name: 'Electronics & Comm (EC)',
    icon: 'Radio',
    color: 'from-pink-500 to-rose-600',
    tagline: '5G Architecture, RF Engineering, & Satellite Network Operations',
    description: 'Learn cellular networking standards, antenna arrays, SDR (Software Defined Radio) and telecom operations planning.',
    certificate6m: {
      duration: '6 Months | High Fidelity Lab Emulators | Evening Batch',
      eligibility: 'BE / B.Tech ECE / EEE — Fresh grads and early professionals',
      whoShouldEnroll: 'Aspiring telecom planners, Radio Frequency technicians, and network specialists.',
      syllabus: [
        '5G & Wireless Communication Technologies',
        'Embedded C & Microcontroller Programming',
        'Signal & Image Processing with Python',
        'Network Design & Protocols (TCP/IP, OSPF, BGP)',
        'Antenna Design & RF Engineering',
        'FPGA Programming (Verilog / VHDL)',
        'IoT & M2M Communication Systems'
      ],
      capstone: [
        '5G Small Cell RF Coverage Optimisation Map',
        'SDR-based FM Receiver with GNU Radio',
        'Multi-Node Network Mesh Routing Simulator'
      ],
      tools: ['Cisco Packet Tracer', 'MATLAB', 'Xilinx Vivado', 'NS3 Network Simulator', 'GNU Radio', 'HFSS'],
      placementSupport: [
        'CCNA Prep validation',
        'Network design scenario exams',
        '3 Rounds domain interview prep',
        'Direct connection into Jio/Airtel/Nokia/isro supply cells'
      ],
      fee: '₹46,000 | Easy EMI from ₹3,830/mo'
    },
    diploma1y: {
      duration: '12 Months | Blended | Interactive Telecom Simulator Modules',
      eligibility: 'BE / B.Tech / M.Tech in ECE / Electronics / CS / IT',
      whoShouldEnroll: 'Network engineers, telecom leads, and defense communications architects.',
      tracks: [
        '🎓 FRESHER TRACK: Cellular basics, routing, packet trace and placements',
        '💼 EXPERIENCED TRACK: V2X connected communication + SDN/NFV software deep dives',
        '🧑‍💼 MANAGER TRACK: Global telecom compliance, spectrum auctions & executive operational decisions'
      ],
      curriculum: [
        'Advanced 5G / 6G Network Architecture & Planning',
        'AI / ML for Telecom & Network Optimisation',
        'Autonomous & Connected Vehicle Communication (V2X)',
        'Software Defined Networking (SDN) & NFV',
        'Satellite & Space Communication Systems',
        'Cybersecurity for Communication Networks',
        'Edge Computing & Fog Networks',
        'Telecom Project Management & Regulatory Compliance',
        'Leadership in Telecom & IT for Managers'
      ],
      coreSkills: [
        'Cellular Network Dimensioning',
        'SDN Controller Orchestrator Configuration',
        'RF Link Budget planning',
        'Network Attack Threat modeling'
      ],
      tools: ['MATLAB/RF Toolbox', 'Python NetworkX', 'HFSS', 'Cisco Packet Tracer', 'NS3', 'Rover Emulators'],
      targets: ['Telecommunications conglomerates, space agencies (ISRO/DRDO partners), satellite networks'],
      roles: ['5G Network Architect', 'RF Optimization Lead', 'Broadband Core Engineer', 'Telecom Project Manager'],
      fee: '₹90,000 | Zero-Cost EMI from ₹7,500/mo'
    }
  },
  {
    id: 'computer',
    name: 'Computer Engineering',
    icon: 'Laptop',
    color: 'from-violet-500 to-fuchsia-600',
    tagline: 'Full Stack Web, Cloud Architecture, Analytics & Generative AI',
    description: 'Learn modern software scaling. Master React, Node, AWS solutions architecture, and build complete GenAI multi-agent modules.',
    certificate6m: {
      duration: '6 Months | Active GitHub Portfolio Build | Daily Interactive Labs',
      eligibility: 'BE / B.Tech / BCA / MCA / BSc CS — All tech backgrounds',
      whoShouldEnroll: 'Beginners or branch-switchers who want to build a highly active GitHub portfolio and master full stack apps.',
      syllabus: [
        'Full Stack Development (React + Node.js / Django)',
        'Data Science & Machine Learning with Python',
        'Cloud Computing Fundamentals (AWS / Azure / GCP)',
        'Database Design — SQL & NoSQL',
        'DevOps & CI/CD Pipelines',
        'Cybersecurity Essentials',
        'Generative AI & LLM Applications'
      ],
      capstone: [
        'Full Stack LMS with Interactive Progress & Video Player',
        'Enterprise RAG Knowledgebot with Vector DB',
        'CI/CD Pipeline with Docker, Github Actions'
      ],
      tools: ['VS Code', 'React', 'NodeJS', 'AWS Cloud', 'Docker', 'PostgreSQL', 'Git/GitHub'],
      placementSupport: [
        'GitHub Portfolio Review & Polish',
        'LeetCode/HackerRank DSA training',
        '3 Rounds Tech Mock panel with Senior Engineers',
        'FAANG & hot startup direct recruiting drives'
      ],
      fee: '₹49,000 | Easy EMI from ₹4,080/mo'
    },
    diploma1y: {
      duration: '12 Months | Blended | Advanced System Design Capstones',
      eligibility: 'Graduates or professionals wanting deep Cloud, MLOps, or Engineering Leadership roles.',
      whoShouldEnroll: 'Experienced software professionals, backend developers & IT managers aiming for cloud, MLOps, or CTO roles.',
      tracks: [
        '🎓 FRESHER TRACK: Full stack + Cloud fundamentals + Coding sprint',
        '💼 EXPERIENCED TRACK: Scalable system design + Agentic Workflows + MLOps',
        '🧑‍💼 MANAGER TRACK: Tech product strategy, engineering delivery & CTO decision engines'
      ],
      curriculum: [
        'Advanced AI / ML & Deep Learning',
        'MLOps & AI Deployment Lifecycle',
        'Agentic AI & Autonomous Workflow Systems',
        'Cloud Architecture & Solution Design',
        'Blockchain & Web3 Development',
        'Data Engineering & Big Data (Spark, Kafka)',
        'Product Management for Tech Professionals',
        'System Design & Scalable Architecture',
        'Tech Leadership & Engineering Management'
      ],
      coreSkills: [
        'Distributed System Scalability',
        'Agentic Workflow orchestration',
        'CI/CD/CD Automation',
        'Big Data streaming pipelines',
        'Predictive Model orchestration'
      ],
      tools: ['AWS', 'K8s', 'Docker', 'TensorFlow', 'PyTorch', 'Apache Spark', 'Kafka', 'React/NextJS'],
      targets: ['MNC Product groups, global FinTechs, Autonomous Systems agencies, scale SaaS startups'],
      roles: ['MLOps Architect', 'Lead Full Stack Specialist', 'Senior System Designer', 'VP of Engineering', 'CTO'],
      fee: '₹98,000 | Zero-Cost EMI from ₹8,160/mo'
    }
  }
];

export const TESTIMONIALS: Testimonial[] = [
  {
    name: 'Rahul Sharma',
    role: 'Alumni — Fresher Track',
    company: 'ABB Power Systems',
    text: 'I was a non-CS engineering student with zero placement assurance. Sixsigma AI’s 6 Months Certificate course completely reshaped my perspective. Their hands-on SCADA/Simulink and smart grid training helped me crack the ABB interview on my very first try!',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    outcome: 'Placed as Smart Grid Analyst @ ₹6.5 LPA'
  },
  {
    name: 'Meera Deshmukh',
    role: 'Alumni — Experienced Track',
    company: 'L&T Construction',
    text: 'With 4 years of site supervisor experience, my career was stagnant. The 1 Year Advanced Professional Diploma in Civil BIM & Drone technology opened huge opportunities. I switched to the designing division instantly with a 70% salary hike.',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    outcome: 'Promoted to BIM Engineering Coordinator @ ₹11.5 LPA'
  },
  {
    name: 'David Abraham',
    role: 'Alumni — Managers Track',
    company: 'Tata Motors EV Division',
    text: 'As an engineering manager, mastering EV battery optimization and Lean Six Sigma techniques was critical. The cohort structure was exceptionally rich, featuring top managers from across the globe.',
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    outcome: 'Director of EV Operations @ ₹24 LPA'
  }
];

export const PLACEMENT_STATS: PlacementStat[] = [
  { branch: 'Electrical', highestPackage: '₹14 LPA', averagePackage: '₹6.8 LPA', placementRate: 88 },
  { branch: 'Mechanical', highestPackage: '₹12.5 LPA', averagePackage: '₹6.2 LPA', placementRate: 86 },
  { branch: 'Civil', highestPackage: '₹10.5 LPA', averagePackage: '₹5.8 LPA', placementRate: 84 },
  { branch: 'Electronics', highestPackage: '₹18 LPA', averagePackage: '₹8.2 LPA', placementRate: 91 },
  { branch: 'EC', highestPackage: '₹15.5 LPA', averagePackage: '₹7.4 LPA', placementRate: 89 },
  { branch: 'Computer', highestPackage: '₹25 LPA', averagePackage: '₹11.2 LPA', placementRate: 94 }
];

export const RECRUITERS = [
  { name: 'ABB', logo: '⚡ ABB' },
  { name: 'Siemens', logo: '⚙️ Siemens' },
  { name: 'Schneider', logo: '🔌 Schneider' },
  { name: 'L&T', logo: '🏗️ L&T' },
  { name: 'Tata Motors', logo: '🚘 Tata' },
  { name: 'Bosch', logo: '🔧 Bosch' },
  { name: 'Nokia', logo: '📡 Nokia' },
  { name: 'Ericsson', logo: '📟 Ericsson' },
  { name: 'ISRO', logo: '🌌 ISRO' },
  { name: 'DRDO', logo: '🛡️ DRDO' },
  { name: 'Jio', logo: '🌐 Jio' },
  { name: 'TCS', logo: '💻 TCS' },
  { name: 'Infosys', logo: '💻 Infosys' },
  { name: 'Google', logo: '🔍 Google' },
  { name: 'Microsoft', logo: '🖥️ Microsoft' }
];

export const MOCK_COURSES = [
  {
    id: 'electrical-smartgrid',
    title: 'Advanced Smart Grid Operations & AI Diagnostics',
    description: 'Learn modern electrical assets, power diagnostics and automated smart grid integration techniques.',
    category: 'Electrical',
    rating: 4.8,
    reviewsCount: 1240,
    lessons: [
      { title: 'Introduction to Smart Microgrids & Distributed Energy', duration: '12:45', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
      { title: 'Designing Grid Isolation & Fault Diagnostics', duration: '15:20', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' },
      { title: 'Predictive Diagnostic Models for Substations', duration: '18:10', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
      { title: 'Industrial SCADA Systems Simulation with MATLAB', duration: '22:40', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' }
    ],
    resources: [
      { name: 'Simulink Smart Grid Sandbox File (.slx)', size: '24.5 MB' },
      { name: 'ISO 50001 Energy Audit Checklist Checklist Template (.xlsx)', size: '1.2 MB' },
      { name: 'Substation Machine Automation Syllabus Companion Manual (.pdf)', size: '14.8 MB' }
    ]
  },
  {
    id: 'sixsigma-blackbelt',
    title: 'Lean Six Sigma Black Belt Expert Certification',
    description: 'Master DMAIC, hypothesis testing, SPC, DMADV, and design of experiments to drive top-tier process excellence.',
    category: 'Process Excellence',
    rating: 4.9,
    reviewsCount: 3120,
    lessons: [
      { title: 'Overview of Six Sigma & DMAIC Framework Philosophy', duration: '14:22', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
      { title: 'Define & Measure Phase — CTQ Trees and SIPOC', duration: '19:45', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' },
      { title: 'Analyze Phase — Data Normality Testing using Minitab', duration: '25:12', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
      { title: 'Improve & Control Phase — SPC Charts & Poka-Yoke Systems', duration: '21:30', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' }
    ],
    resources: [
      { name: 'Lean Six Sigma DMAIC Templates Kit (.zip)', size: '48.2 MB' },
      { name: 'Minitab Statistical Analysis Guidelines (.pdf)', size: '3.4 MB' },
      { name: 'Industrial Continuous Improvement Handout (.pdf)', size: '8.2 MB' }
    ]
  },
  {
    id: 'computer-mlops',
    title: 'MLOps Architect: Scalable Systems & Agentic Workflows',
    description: 'Learn distributed model containerisation, Kubernetes orchestration, and autonomous agent systems.',
    category: 'Computer',
    rating: 4.9,
    reviewsCount: 1980,
    lessons: [
      { title: 'Introduction to MLOps Pipelines and System Architecture', duration: '11:10', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4' },
      { title: 'Containerising Models with Docker & Simple API Wrappers', duration: '18:40', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4' },
      { title: 'Model Orchestration with Kubernetes & Helm Charts', duration: '24:15', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4' },
      { title: 'Building Multi-Agent Systems with LangGraph & Python', duration: '28:50', videoUrl: 'https://storage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4' }
    ],
    resources: [
      { name: 'Orchestrator Helm Chart Helm Values File (.yaml)', size: '150 KB' },
      { name: 'LangGraph Autonomous Multi-Agent Boilerplate (.py)', size: '4.2 MB' },
      { name: 'Production Scaling Guidelines & Memory Limits (.pdf)', size: '6.7 MB' }
    ]
  }
];
