/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export type UserRole = 'fresher' | 'experienced' | 'manager';

export interface UserSession {
  isLoggedIn: boolean;
  user: {
    name: string;
    email: string;
    role: UserRole;
    branch: string;
    isPremium: boolean;
  } | null;
}

export type ViewState = 
  | { type: 'home' }
  | { type: 'programmes'; audience: UserRole }
  | { type: 'branch'; branchId: string }
  | { type: 'process-excellence'; progId: 'six-sigma' | 'kaizen' | '5s' }
  | { type: 'placement' }
  | { type: 'corporate' }
  | { type: 'insights' }
  | { type: 'about' }
  | { type: 'auth'; isSignUp: boolean }
  | { type: 'checkout'; plan: { name: string; price: number; type: string; branchId?: string } }
  | { type: 'dashboard' }
  | { type: 'player'; courseId: string; lectureIndex: number };

export interface BranchInfo {
  id: string;
  name: string;
  icon: string;
  color: string;
  tagline: string;
  description: string;
  certificate6m: {
    duration: string;
    eligibility: string;
    whoShouldEnroll: string;
    syllabus: string[];
    capstone: string[];
    tools: string[];
    placementSupport: string[];
    fee: string;
  };
  diploma1y: {
    duration: string;
    eligibility: string;
    whoShouldEnroll: string;
    tracks: string[];
    curriculum: string[];
    coreSkills: string[];
    tools: string[];
    targets: string[];
    roles: string[];
    fee: string;
  };
}

export interface Testimonial {
  name: string;
  role: string;
  company: string;
  text: string;
  avatar: string;
  outcome: string;
}

export interface PlacementStat {
  branch: string;
  highestPackage: string;
  averagePackage: string;
  placementRate: number;
}
