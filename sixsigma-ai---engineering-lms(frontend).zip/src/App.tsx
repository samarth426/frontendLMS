/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { UserSession, ViewState } from './types';
import Navbar from './components/Navbar';
import LandingPage from './components/LandingPage';
import AudienceTrack from './components/AudienceTrack';
import BranchDetail from './components/BranchDetail';
import ProcessExcellence from './components/ProcessExcellence';
import PlacementPage from './components/PlacementPage';
import AuthInterface from './components/AuthInterface';
import StudentDashboard from './components/StudentDashboard';
import CoursePlayer from './components/CoursePlayer';
import CheckoutPage from './components/CheckoutPage';
import { CorporateTraining, InsightsPage, AboutPage } from './components/EnterpriseSections';
import AITutorChat from './components/AITutorChat';

export default function App() {
  // Read session from local storage to keep state intact on compile
  const [session, setSession] = useState<UserSession>(() => {
    const saved = localStorage.getItem('sixsigma_session');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // Fallback
      }
    }
    return { isLoggedIn: false, user: null };
  });

  const [view, setView] = useState<ViewState>(() => {
    const savedView = localStorage.getItem('sixsigma_view');
    if (savedView) {
      try {
        return JSON.parse(savedView);
      } catch (e) {}
    }
    return { type: 'home' };
  });

  const [isAITutorOpen, setIsAITutorOpen] = useState(false);

  // Sync session and view to localStorage
  useEffect(() => {
    localStorage.setItem('sixsigma_session', JSON.stringify(session));
  }, [session]);

  useEffect(() => {
    localStorage.setItem('sixsigma_view', JSON.stringify(view));
    // Scroll to top upon transition
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [view]);

  const handlePaymentSuccess = () => {
    if (session.isLoggedIn && session.user) {
      setSession({
        ...session,
        user: {
          ...session.user,
          isPremium: true
        }
      });
    } else {
      // Create a temporary guest-premium session
      setSession({
        isLoggedIn: true,
        user: {
          name: 'Ramesh Kumar',
          email: 'ramesh@example.com',
          role: 'fresher',
          branch: 'electrical',
          isPremium: true
        }
      });
    }
  };

  const renderActiveView = () => {
    switch (view.type) {
      case 'home':
        return <LandingPage setView={setView} />;
      
      case 'programmes':
        return <AudienceTrack audience={view.audience} setView={setView} />;
      
      case 'branch':
        return <BranchDetail branchId={view.branchId} setView={setView} />;
      
      case 'process-excellence':
        return <ProcessExcellence progId={view.progId} setView={setView} />;

      case 'placement':
        return <PlacementPage setView={setView} />;

      case 'corporate':
        return <CorporateTraining setView={setView} />;

      case 'insights':
        return <InsightsPage setView={setView} />;

      case 'about':
        return <AboutPage setView={setView} />;

      case 'auth':
        return (
          <AuthInterface 
            session={session} 
            setSession={setSession} 
            setView={setView} 
            isSignUpInitial={view.isSignUp} 
          />
        );

      case 'checkout':
        return (
          <CheckoutPage 
            plan={view.plan} 
            setView={setView} 
            onPaymentSuccess={handlePaymentSuccess} 
          />
        );

      case 'dashboard':
        return (
          <StudentDashboard 
            session={session} 
            setView={setView} 
            onOpenAITutor={() => setIsAITutorOpen(true)} 
          />
        );

      case 'player':
        return (
          <CoursePlayer 
            courseId={view.courseId} 
            initialLectureIndex={view.lectureIndex} 
            setView={setView} 
            session={session} 
          />
        );

      default:
        return <LandingPage setView={setView} />;
    }
  };

  return (
    <div className="bg-[#080C14] min-h-screen text-gray-150 font-sans antialiased flex flex-col justify-between" id="sixsigma-lms-app-frame">
      <div>
        <Navbar 
          session={session} 
          setSession={setSession} 
          view={view} 
          setView={setView} 
        />
        
        <main id="main-content-area">
          {renderActiveView()}
        </main>
      </div>

      {/* Global Footer */}
      <footer className="bg-gray-950 border-t border-gray-900 py-12 text-xs text-gray-500 font-mono tracking-wide" id="global-lms-footer">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row justify-between items-center gap-6">
          <div className="flex items-center space-x-2">
            <span className="font-sans font-bold text-sm text-gray-300">SIXSIGMA AI</span>
            <span className="text-gray-600">│</span>
            <span>Internationally Accredited Engineering LMS</span>
          </div>

          <div className="flex flex-wrap justify-center gap-6">
            <button onClick={() => setView({ type: 'about' })} className="hover:text-amber-400">About Us</button>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('Privacy conditions are fully validated on blockchain nodes.'); }} className="hover:text-amber-400">Privacy Policy</a>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('Refund operations are processed within 48 hours of ticket creation.'); }} className="hover:text-amber-400">Refund Policy</a>
            <a href="#" onClick={(e) => { e.preventDefault(); alert('All certificates carry a unique blockchain hash for employer validation.'); }} className="hover:text-amber-400">Certificates Policy</a>
          </div>

          <div className="text-[10px] text-gray-600">
            &copy; 2026 Sixsigma AI Institute. All rights reserved. Registered ISO 9001:2015.
          </div>
        </div>
      </footer>

      {/* Persistent sliding AI Tutor */}
      <AITutorChat 
        isOpen={isAITutorOpen} 
        onClose={() => setIsAITutorOpen(false)} 
        session={session} 
      />
    </div>
  );
}

